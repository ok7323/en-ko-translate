package com.example.s23quicktranslate

import android.app.Application
import android.os.StatFs
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** GPU uses Adreno OpenCL. Qualcomm Hexagon NPU needs a separately compiled model/SDK. */
enum class ComputeMode { GPU, CPU }

data class TranslatorUiState(
    val checking: Boolean = true,
    val modelPresent: Boolean = false,
    val downloading: Boolean = false,
    val loading: Boolean = false,
    val translating: Boolean = false,
    val ready: Boolean = false,
    val downloadBytes: Long = 0,
    val totalBytes: Long = 0,
    val preferred: ComputeMode = ComputeMode.GPU,
    val actual: ComputeMode? = null,
    val status: String = "설치된 모델을 확인하는 중…",
    val result: String = "",
    val metrics: String = "",
    val error: String? = null
)

class TranslatorViewModel(app: Application) : AndroidViewModel(app) {
    companion object {
        // Apache-2.0 model: litert-community/Qwen3-0.6B-int4, no-thinking INT4 build.
        private const val MODEL_FILENAME = "qwen3_0.6b_nothink_q4_block32_ekv1280.litertlm"
        private const val MODEL_URL =
            "https://huggingface.co/litert-community/Qwen3-0.6B-int4/resolve/main/" + MODEL_FILENAME
        private const val MODEL_SHA256 =
            "2df6821ec12702dafd33915e7a1a1adc7c4b053f3672fd9555dfaf3a114c4139"
        private const val MIN_MODEL_BYTES = 300_000_000L
        private const val ESTIMATED_MODEL_BYTES = 347_000_000L
    }

    private val appContext = getApplication<Application>()
    private val modelFile = File(appContext.filesDir, MODEL_FILENAME)
    private val prefs = appContext.getSharedPreferences("model_validation", 0)
    private val executor = Executors.newSingleThreadExecutor()
    private val dispatcher = executor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private val _state = MutableStateFlow(TranslatorUiState())
    val state: StateFlow<TranslatorUiState> = _state.asStateFlow()

    /** Both Engine and Conversation are touched only on the one dedicated worker thread. */
    private var engine: Engine? = null
    private var activeMode: ComputeMode? = null

    init {
        scope.launch {
            try {
                val valid = verifyExistingModel()
                _state.update {
                    it.copy(
                        checking = false,
                        modelPresent = valid,
                        status = if (valid) "모델 검증 완료" else "모델 다운로드가 필요합니다 · 약 347 MB"
                    )
                }
                if (valid) activateBackend(_state.value.preferred)
            } catch (e: Exception) {
                _state.update { it.copy(checking = false, status = "모델 확인 실패", error = detail(e)) }
            }
        }
    }

    fun downloadModel() {
        if (_state.value.checking || _state.value.downloading || _state.value.modelPresent) return
        _state.update { it.copy(downloading = true, error = null, status = "모델 다운로드 시작…") }
        scope.launch {
            try {
                downloadWithResume()
                _state.update {
                    it.copy(downloading = false, modelPresent = true, status = "무결성 검증 완료 · 로딩 중…")
                }
                activateBackend(_state.value.preferred)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Keep the *.part file so the user can retry and resume later.
                _state.update {
                    it.copy(downloading = false, status = "다운로드 실패 · 다시 누르면 재시도", error = detail(e))
                }
            }
        }
    }

    fun selectMode(mode: ComputeMode) {
        if (_state.value.downloading || _state.value.loading || _state.value.translating) return
        _state.update { it.copy(preferred = mode) }
        if (!_state.value.modelPresent) return
        scope.launch { activateBackend(mode) }
    }

    fun translate(english: String) {
        val source = english.trim()
        if (source.isEmpty()) {
            _state.update { it.copy(error = "번역할 영어 문장을 입력하세요.") }
            return
        }
        if (source.length > 1000) {
            _state.update { it.copy(error = "속도와 문맥 길이를 위해 1,000자 이내로 입력하세요.") }
            return
        }
        if (!_state.value.ready || _state.value.loading || _state.value.translating) return
        _state.update {
            it.copy(translating = true, status = "로컬 번역 중…", result = "", metrics = "", error = null)
        }
        scope.launch {
            try {
                try {
                    runOneTranslation(source)
                } catch (first: CancellationException) {
                    throw first
                } catch (first: Exception) {
                    // GPU initialization may work but the first OpenCL inference may fail.
                    if (activeMode != ComputeMode.GPU) throw first
                    _state.update {
                        it.copy(
                            status = "GPU 실행 오류 → CPU로 재시도 중…",
                            result = "", metrics = "",
                            error = "GPU 오류: ${detail(first)}"
                        )
                    }
                    activateBackend(ComputeMode.CPU)
                    if (engine == null) throw first
                    _state.update { it.copy(error = null) }
                    runOneTranslation(source)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(status = "번역 실패", error = detail(e)) }
            } finally {
                _state.update { it.copy(translating = false) }
            }
        }
    }

    private suspend fun runOneTranslation(source: String) {
        val currentEngine = checkNotNull(engine) { "모델이 준비되지 않았습니다." }
        // A fresh conversation for every sentence avoids unbounded chat history / KV cache growth.
        val settings = ConversationConfig(
            samplerConfig = SamplerConfig(topK = 1, topP = 1.0, temperature = 0.01),
            maxOutputToken = 384
        )
        val prompt = """
            Translate the English text below into natural, accurate Korean.
            Reply with ONLY the Korean translation. No explanation or labels.
            Preserve meaning, names, numbers, punctuation and line breaks.
            English:
            $source
            Korean:
        """.trimIndent()

        val started = SystemClock.elapsedRealtime()
        var firstOutputMs = -1L
        var lastPaint = started
        val output = StringBuilder()
        currentEngine.createConversation(settings).use { conversation ->
            conversation.sendMessageAsync(prompt).collect { chunk ->
                val next = chunk.toString()
                if (next.isNotEmpty()) {
                    val now = SystemClock.elapsedRealtime()
                    if (firstOutputMs < 0) firstOutputMs = now - started
                    output.append(next)
                    // Reduce UI wakeups; inference still streams at full speed.
                    if (now - lastPaint >= 48L) {
                        _state.update { it.copy(result = output.toString()) }
                        lastPaint = now
                    }
                }
            }
        }
        val elapsed = (SystemClock.elapsedRealtime() - started).coerceAtLeast(1)
        val finalText = output.toString().trim()
            .removePrefix("한국어:").removePrefix("번역:").trim()
        _state.update {
            it.copy(
                status = "완료 · 인터넷 없이 기기에서 번역",
                result = finalText,
                metrics = "${if (activeMode == ComputeMode.GPU) "Adreno GPU" else "CPU"}  ·  " +
                    "첫 출력 ${if (firstOutputMs < 0) "-" else "${firstOutputMs}ms"}  ·  " +
                    "전체 ${elapsed}ms  ·  ${"%.1f".format(java.util.Locale.US, finalText.length * 1000.0 / elapsed)}자/초"
            )
        }
    }

    private fun activateBackend(preferred: ComputeMode) {
        if (engine != null && preferred == activeMode) {
            _state.update { it.copy(ready = true, loading = false) }
            return
        }
        _state.update { it.copy(loading = true, ready = false, status = "${preferred.name} 모델 준비 중…", error = null) }
        try {
            engine?.close()
            engine = null
            activeMode = null
            try {
                loadEngine(preferred)
                _state.update {
                    it.copy(
                        ready = true, loading = false, actual = preferred,
                        status = "준비 완료 · ${if (preferred == ComputeMode.GPU) "Adreno GPU (OpenCL)" else "CPU"}"
                    )
                }
            } catch (gpuError: Exception) {
                if (preferred != ComputeMode.GPU) throw gpuError
                // S23 GPU can differ by Android update / driver, so fallback is mandatory.
                loadEngine(ComputeMode.CPU)
                _state.update {
                    it.copy(
                        ready = true, loading = false, actual = ComputeMode.CPU,
                        status = "GPU 사용 불가 · CPU 자동 전환됨",
                        error = "GPU 초기화: ${detail(gpuError)}"
                    )
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.update {
                it.copy(ready = false, loading = false, actual = null, status = "모델 실행 실패", error = detail(e))
            }
        }
    }

    private fun loadEngine(mode: ComputeMode) {
        val backend = if (mode == ComputeMode.GPU) Backend.GPU() else Backend.CPU()
        val candidate = Engine(
            EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = backend,
                cacheDir = appContext.cacheDir.absolutePath
            )
        )
        // Never call close() on Engine if initialize() throws (LiteRT-LM API contract).
        candidate.initialize()
        engine = candidate
        activeMode = mode
    }

    private fun verifyExistingModel(): Boolean {
        if (!modelFile.isFile || modelFile.length() < MIN_MODEL_BYTES) return false
        val cached = prefs.getBoolean("verified", false) &&
            prefs.getLong("length", -1L) == modelFile.length()
        if (cached) return true
        if (sha256(modelFile) != MODEL_SHA256) return false
        saveVerified()
        return true
    }

    private fun downloadWithResume() {
        val partial = File(appContext.filesDir, "$MODEL_FILENAME.part")
        if (partial.exists() && partial.length() > 450_000_000L) partial.delete()
        val existing = if (partial.isFile) partial.length() else 0L
        val available = StatFs(appContext.filesDir.absolutePath).availableBytes
        val needed = (ESTIMATED_MODEL_BYTES - existing + 60_000_000L).coerceAtLeast(60_000_000L)
        require(available > needed) { "저장 공간이 부족합니다. 최소 ${needed / 1_000_000}MB가 필요합니다." }

        val connection = URL(MODEL_URL).openConnection() as HttpURLConnection
        connection.connectTimeout = 20_000
        connection.readTimeout = 45_000
        connection.setRequestProperty("Accept-Encoding", "identity")
        connection.setRequestProperty("User-Agent", "S23QuickTranslate/1.0")
        if (existing > 0L) connection.setRequestProperty("Range", "bytes=$existing-")
        try {
            val code = connection.responseCode
            require(code == HttpURLConnection.HTTP_OK || code == HttpURLConnection.HTTP_PARTIAL) {
                "다운로드 HTTP $code"
            }
            val append = existing > 0L && code == HttpURLConnection.HTTP_PARTIAL
            val initial = if (append) existing else 0L
            val remaining = connection.contentLengthLong
            val total = if (remaining > 0L) initial + remaining else ESTIMATED_MODEL_BYTES
            var current = initial
            var lastUpdate = 0L
            connection.inputStream.use { input ->
                FileOutputStream(partial, append).use { out ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        out.write(buffer, 0, count)
                        current += count
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastUpdate >= 120) {
                            _state.update {
                                it.copy(downloadBytes = current, totalBytes = total,
                                    status = "모델 다운로드 중 · ${current / 1_000_000} MB")
                            }
                            lastUpdate = now
                        }
                    }
                    out.fd.sync()
                }
            }
        } finally {
            connection.disconnect()
        }
        require(partial.length() >= MIN_MODEL_BYTES) { "모델 파일이 완전히 다운로드되지 않았습니다." }
        _state.update { it.copy(status = "SHA-256으로 파일 검사 중…") }
        require(sha256(partial) == MODEL_SHA256) {
            // Usually an interrupted HTTP transfer or corrupt file. A resume is possible after deletion.
            partial.delete()
            "모델 무결성 검사 실패. 다운로드를 다시 시도하세요."
        }
        if (modelFile.exists()) modelFile.delete()
        check(partial.renameTo(modelFile)) { "모델 파일 저장 실패" }
        saveVerified()
    }

    private fun saveVerified() {
        prefs.edit().putBoolean("verified", true).putLong("length", modelFile.length()).apply()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(512 * 1024).use { input ->
            val bytes = ByteArray(512 * 1024)
            while (true) {
                val n = input.read(bytes)
                if (n < 0) break
                digest.update(bytes, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun detail(e: Throwable): String =
        (e.message?.take(220) ?: e.javaClass.simpleName)

    override fun onCleared() {
        scope.launch {
            try {
                engine?.close()
                engine = null
            } finally {
                dispatcher.close()
                scope.cancel()
                executor.shutdown()
            }
        }
        super.onCleared()
    }
}
