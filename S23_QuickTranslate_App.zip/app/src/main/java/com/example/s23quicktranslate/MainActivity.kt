package com.example.s23quicktranslate

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

class MainActivity : ComponentActivity() {
    private val viewModel: TranslatorViewModel by viewModels()
    private lateinit var input: EditText
    private lateinit var result: TextView
    private lateinit var status: TextView
    private lateinit var backendText: TextView
    private lateinit var downloadLabel: TextView
    private lateinit var metrics: TextView
    private lateinit var downloadButton: Button
    private lateinit var translateButton: Button
    private lateinit var copyButton: Button
    private lateinit var backendGroup: RadioGroup
    private lateinit var radioGpu: RadioButton
    private lateinit var radioCpu: RadioButton
    private lateinit var downloadProgress: ProgressBar
    private var updatingUi = false
    private var lastError: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input = findViewById(R.id.inputText)
        result = findViewById(R.id.resultText)
        status = findViewById(R.id.statusText)
        backendText = findViewById(R.id.backendText)
        downloadLabel = findViewById(R.id.downloadLabel)
        metrics = findViewById(R.id.metricsText)
        downloadButton = findViewById(R.id.downloadButton)
        translateButton = findViewById(R.id.translateButton)
        copyButton = findViewById(R.id.copyButton)
        backendGroup = findViewById(R.id.backendGroup)
        radioGpu = findViewById(R.id.radioGpu)
        radioCpu = findViewById(R.id.radioCpu)
        downloadProgress = findViewById(R.id.downloadProgress)

        downloadButton.setOnClickListener { viewModel.downloadModel() }
        translateButton.setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            input.clearFocus()
            viewModel.translate(input.text.toString())
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            input.text.clear()
            input.requestFocus()
        }
        copyButton.setOnClickListener {
            val text = viewModel.state.value.result
            if (text.isNotBlank()) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("한국어 번역", text))
                Toast.makeText(this, "번역을 복사했습니다.", Toast.LENGTH_SHORT).show()
            }
        }
        backendGroup.setOnCheckedChangeListener { _, id ->
            if (!updatingUi) {
                viewModel.selectMode(if (id == R.id.radioCpu) ComputeMode.CPU else ComputeMode.GPU)
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect { render(it) }
            }
        }
    }

    private fun render(s: TranslatorUiState) {
        val busy = s.checking || s.downloading || s.loading || s.translating
        status.text = s.status
        backendText.text = when (s.actual) {
            ComputeMode.GPU -> "현재 실행: Adreno GPU (OpenCL)"
            ComputeMode.CPU -> "현재 실행: CPU · GPU보다 빠를 수도 있습니다"
            null -> "첫 실행은 GPU를 시도하고 오류 시 CPU로 전환합니다."
        }
        if (s.result.isNotEmpty()) {
            result.text = s.result
        } else if (s.translating) {
            result.text = "번역 중…"
        } else if (!s.ready) {
            result.text = "모델 준비 후 번역 결과가 표시됩니다."
        } else if (s.metrics.isEmpty()) {
            result.text = "영어 문장을 입력하고 '즉시 번역'을 누르세요."
        } else {
            result.text = "번역 결과가 비어 있습니다. 문장을 다시 시도하세요."
        }
        metrics.text = when {
            s.metrics.isNotBlank() -> s.metrics
            s.error != null -> "오류: ${s.error}"
            else -> "첫 출력 시간과 전체 처리 시간을 실제 측정합니다."
        }
        downloadButton.visibility = if (s.modelPresent) View.GONE else View.VISIBLE
        downloadButton.isEnabled = !busy && !s.modelPresent
        downloadButton.text = if (s.downloading) "모델 다운로드 중…" else "모델 내려받기 · 약 347 MB"
        translateButton.isEnabled = s.ready && !busy
        translateButton.text = if (s.translating) "번역 중…" else "즉시 번역"
        backendGroup.isEnabled = !busy
        radioGpu.isEnabled = !busy
        radioCpu.isEnabled = !busy
        copyButton.isEnabled = s.result.isNotBlank()

        updatingUi = true
        // Show the real backend after fallback rather than a misleading GPU selection.
        val shown = if (s.ready) s.actual ?: s.preferred else s.preferred
        if (shown == ComputeMode.GPU) radioGpu.isChecked = true else radioCpu.isChecked = true
        updatingUi = false

        downloadProgress.visibility = if (s.downloading) View.VISIBLE else View.GONE
        downloadLabel.visibility = if (s.downloading) View.VISIBLE else View.GONE
        if (s.downloading) {
            val denominator = s.totalBytes.coerceAtLeast(1L)
            val percent = ((s.downloadBytes * 100L) / denominator).coerceIn(0L, 100L).toInt()
            downloadProgress.progress = percent
            downloadLabel.text = "${s.downloadBytes / 1_000_000} / ${denominator / 1_000_000} MB · $percent%"
        }
        if (s.error != null && s.error != lastError) {
            Toast.makeText(this, s.error, Toast.LENGTH_LONG).show()
        }
        lastError = s.error
    }
}
