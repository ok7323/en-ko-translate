# Galaxy S23 QuickTranslate · ZIP 직접 업로드용 소스

영어 → 한국어 오프라인 번역 Android 앱입니다. Samsung Galaxy S23의 Adreno GPU를 우선 시도하고 실패하면 CPU로 전환합니다. 번역 모델은 APK에 포함되지 않으며 앱 실행 후 최초 1회 다운로드합니다.

## GitHub Actions에 ZIP 파일 그대로 업로드하기

**중요:** GitHub는 업로드된 ZIP을 자동으로 풀지 않습니다. 따라서 저장소를 처음 만들 때에는 `.github/workflows/build-apk.yml` 파일을 한 번만 등록해야 합니다. 이후에는 ZIP 파일만 업로드/교체하면 자동 빌드됩니다.

1. GitHub에서 새 저장소를 만듭니다 (`main` 브랜치).
2. `Add file` → `Create new file`을 누르고 파일 이름에 `.github/workflows/build-apk.yml`을 입력한 다음, 별도로 제공된 `build-apk.yml`의 내용을 복사하여 저장합니다.
3. GitHub 저장소의 `Add file` → `Upload files`에서 **이 ZIP(`S23_QuickTranslate_App.zip`)을 압축 해제하지 않고** 그대로 업로드합니다. 저장소 최상단(root)에 업로드해야 합니다.
4. 커밋하면 GitHub Actions에서 자동으로 ZIP을 풀어 Android SDK 및 Gradle 8.13으로 `:app:assembleDebug`를 실행합니다.
5. `Actions` → `Build S23 APK from ZIP` → 성공한 실행 → `Artifacts` → `S23QuickTranslate-debug-apk`를 내려받습니다.
6. 결과물의 `app-debug.apk`를 Galaxy S23에 설치합니다. 앱 내에서 약 347 MB의 모델을 따로 받으세요.

Workflow를 처음 저장했을 때는 ZIP이 아직 없으면 빌드를 건너뜁니다. ZIP을 올린 시점에 자동으로 실행됩니다.

## 프로젝트 정보

- Android Gradle Plugin: 8.13.2
- Kotlin: 2.3.0
- LiteRT-LM Android: 0.18.0
- API: compileSdk 36, minSdk 26, targetSdk 35
- GPU 우선, CPU 폴백, 번역 스트리밍, 다운로드 SHA-256 검사, 오프라인 실행
- 테스트용 `debug` APK 빌드 (Play Store 릴리스용 아님)

이 ZIP은 **실행 가능한 APK가 아닌 소스 코드**입니다. Android SDK와 실물 기기 테스트 환경 없이 준비되었으므로 GitHub에서 실제 빌드 및 GPU 작동 여부는 아직 검증되지 않았습니다.
