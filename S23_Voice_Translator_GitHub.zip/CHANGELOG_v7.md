# v7.0: English-first transcript

- As soon as one nonempty ASR partial arrives, immediately create an English transcript card.
- Update an in-progress card instead of adding duplicates on every partial.
- Finalize the existing draft and enqueue Korean translation without waiting to create English.
- Keep English even if final callback is missing, translation model is not installed, translation fails, or user stops listening.
- Make microphone available with on-device ASR even when Korean translation model is absent.
- Store draft updates in existing JSONL journal, maintaining compatibility with v5/v6 records.
- Distinguish active English hypotheses in the transcript list.
- Preserve optional local persistence preference (enabled by default); this feature cannot record speech that Android ASR never recognized.

Build verification: Kotlin-only lifecycle smoke test, archive/XML checks; Android APK build still requires GitHub Actions.
