package com.example.s23quicktranslate

import org.junit.Assert.*
import org.junit.Test

class AdaptiveNoiseGateTest {
    @Test fun steadyBackgroundNoiseDoesNotOpenGate() {
        val gate = AdaptiveNoiseGate(true, NoiseFilterLevel.NORMAL)
        repeat(30) { gate.sample(0.4f, it * 80L) }
        assertFalse(gate.voiceDetected)
        assertFalse(gate.acceptsText())
    }

    @Test fun shortTinyNoisePulseIsRejected() {
        val gate = AdaptiveNoiseGate(true, NoiseFilterLevel.NORMAL)
        repeat(12) { gate.sample(0.1f, it * 80L) }
        gate.sample(4.8f, 1000)
        repeat(10) { gate.sample(0.2f, 1100 + it * 80L) }
        assertFalse(gate.voiceDetected)
        assertFalse(gate.acceptsText())
    }

    @Test fun voiceRiseOpensGateAndQuietEndsPhrase() {
        val gate = AdaptiveNoiseGate(true, NoiseFilterLevel.NORMAL)
        repeat(12) { gate.sample(0.5f, it * 80L) }
        gate.sample(5.2f, 1000)
        gate.sample(5.6f, 1080)
        assertTrue(gate.voiceDetected)
        assertTrue(gate.acceptsText())
        assertFalse(gate.silenceConfirmed(2100))
        assertTrue(gate.silenceConfirmed(2281))
    }

    @Test fun stricterSettingBlocksSmallerRise() {
        val gate = AdaptiveNoiseGate(true, NoiseFilterLevel.STRONG)
        repeat(8) { gate.sample(0.5f, it * 50L) }
        repeat(3) { gate.sample(3.3f, 500L + it * 80L) }
        assertFalse(gate.voiceDetected)
    }

    @Test fun disabledGateNeverDiscardsRecognizedEnglish() {
        val gate = AdaptiveNoiseGate(false, NoiseFilterLevel.STRONG)
        repeat(10) { gate.sample(-1f, it * 100L) }
        assertTrue(gate.acceptsText())
        assertFalse(gate.silenceConfirmed(99_000))
    }

    @Test fun noRmsServiceKeepsEnglishRecognitionWorking() {
        val gate = AdaptiveNoiseGate(true, NoiseFilterLevel.NORMAL)
        assertTrue(gate.acceptsText())
        assertFalse(gate.rmsAvailable())
    }
}
