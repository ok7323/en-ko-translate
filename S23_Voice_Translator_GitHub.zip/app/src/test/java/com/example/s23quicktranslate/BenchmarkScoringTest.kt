package com.example.s23quicktranslate

import org.junit.Assert.*
import org.junit.Test

class BenchmarkScoringTest {
    @Test fun exactSentenceIsZero() {
        val c = BenchmarkCases.all.first { it.id == "G01" }
        assertEquals(0, BenchmarkScoring.score(c.referenceEnglish, "HELLO hello!").errors)
    }
    @Test fun omissionIsHundredPercent() {
        val score = BenchmarkScoring.score("Please wait a moment", "")
        assertEquals(4, score.referenceWords)
        assertEquals(4, score.errors)
        assertEquals(100.0, score.werPercent, 0.001)
    }
    @Test fun substitutionsAndInsertsCount() {
        val score = BenchmarkScoring.score("we will meet", "we may meet soon")
        assertEquals(2, score.errors)
        assertEquals(3, score.referenceWords)
    }
    @Test fun apostrophesNormalize() {
        assertEquals(0, BenchmarkScoring.score("Today's service", "today’s service").errors)
    }
    @Test fun testDeckMatchesTablet() {
        assertEquals(22, BenchmarkCases.all.size)
        assertEquals(20, BenchmarkCases.all.count { !it.isNoise })
        assertEquals(2, BenchmarkCases.all.count { it.isNoise })
    }
    @Test fun noSoundFalsePositive() {
        val t = BenchmarkTrial(1L, "N01", "백색 소음", 1, "v10", "중", "일반", "hello", "",
            false, false, 0, null, null, 1)
        assertTrue(t.falsePositive)
    }
}
