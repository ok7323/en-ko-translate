package com.example.s23quicktranslate

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SpeechRecoveryGateTest {
    @Test fun finalIsPreferredOverPartialAndOnlySavedOnce() {
        val gate = SpeechRecoveryGate()
        gate.onPartial("Hello, hello")
        assertEquals("Hello, hello.", gate.takeFinalOrPartial("Hello, hello."))
        assertNull(gate.takeFallback())
    }

    @Test fun lostFinalUsesLatestPartialAndDeduplicates() {
        val gate = SpeechRecoveryGate()
        gate.onPartial("Hello")
        gate.onPartial("Hello, hello.")
        assertEquals("Hello, hello.", gate.takeFallback())
        assertNull(gate.takeFinalOrPartial("Hello, hello."))
    }

    @Test fun blankResultsStillRecoverLastPartial() {
        val gate = SpeechRecoveryGate()
        gate.onPartial("Do you hear me?")
        assertEquals("Do you hear me?", gate.takeFinalOrPartial(""))
    }

    @Test fun resetDoesNotLoseFutureUtterances() {
        val gate = SpeechRecoveryGate()
        gate.onPartial("First")
        gate.takeFallback()
        gate.reset()
        gate.onPartial("Second")
        assertEquals("Second", gate.takeFinalOrPartial(""))
    }

    @Test fun noSpeechCreatesNoRecord() {
        val gate = SpeechRecoveryGate()
        assertNull(gate.takeFallback())
    }
}
