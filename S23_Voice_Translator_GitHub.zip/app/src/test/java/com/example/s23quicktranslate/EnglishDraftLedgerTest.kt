package com.example.s23quicktranslate

import org.junit.Assert.*
import org.junit.Test

class EnglishDraftLedgerTest {
    @Test fun onePartialCreatesAnEnglishCardImmediately() {
        val ledger = EnglishDraftLedger()
        val first = ledger.partial(" Hello ") { 1L }!!
        assertEquals(EnglishRecordAction.ADD_DRAFT, first.action)
        assertEquals("Hello", first.english)
        assertTrue(ledger.hasDraft)
    }

    @Test fun changingPartialRevisesSameCardAndFinalDoesNotDuplicate() {
        val ledger = EnglishDraftLedger()
        val first = ledger.partial("Hello") { 1L }!!
        val second = ledger.partial("Hello, hello.") { 2L }!!
        val final = ledger.final("Hello, hello.") { 3L }!!
        assertEquals(first.id, second.id)
        assertEquals(first.id, final.id)
        assertEquals(EnglishRecordAction.REVISE_DRAFT, second.action)
        assertEquals(EnglishRecordAction.FINALIZE_DRAFT, final.action)
        assertFalse(ledger.hasDraft)
    }

    @Test fun blankFinalStillPreservesLastEnglishHypothesis() {
        val ledger = EnglishDraftLedger()
        ledger.partial("I believe") { 4L }
        assertEquals("I believe", ledger.final("") { 5L }!!.english)
        assertFalse(ledger.hasDraft)
    }

    @Test fun finalOnlyRecognizerCreatesOneCardAndRepeatedSpeechGetsNextId() {
        val ledger = EnglishDraftLedger()
        val a = ledger.final("Amen") { 1L }!!
        val b = ledger.final("Amen") { 2L }!!
        assertEquals(EnglishRecordAction.ADD_FINAL, a.action)
        assertEquals(1L, a.id)
        assertEquals(2L, b.id)
    }

    @Test fun emptyResultsDoNotCreatePhantomRecords() {
        val ledger = EnglishDraftLedger()
        assertNull(ledger.partial(" ") { 1L })
        assertNull(ledger.final("") { 1L })
    }
}
