package com.example.s23quicktranslate

import org.junit.Assert.assertEquals
import org.junit.Test

class StableSpeechTest {
    @Test fun stableCommonPrefix() {
        assertEquals("I think we", StableSpeech.unchangedPrefix("I think we", "I think we should go"))
    }

    @Test fun changesNeverBecomeStable() {
        assertEquals("I think", StableSpeech.unchangedPrefix("I think should", "I think could"))
    }

    @Test fun singleWordIsNotTranslated() {
        assertEquals("", StableSpeech.unchangedPrefix("hello", "hello world"))
    }

    @Test fun whitespaceAndCaseAreNormalized() {
        assertEquals("Hello There", StableSpeech.unchangedPrefix("hello   there now", "Hello There later"))
    }
}
