package com.example.s23quicktranslate

import org.junit.Assert.assertEquals
import org.junit.Test

class ContextualTranslationTest {
    @Test fun interviewQuestionReceivesNaturalPoliteKorean() {
        assertEquals("자기소개를 부탁드립니다.", ContextualTranslation.refine(
            "Tell me about yourself.", "자신에 대해 말해주세요.", ConversationContext.INTERVIEW))
    }

    @Test fun religiousTermOnlyChangesWhenEnglishMatches() {
        assertEquals("성령의 인도", ContextualTranslation.refine(
            "The Holy Spirit's guidance", "거룩한 영의 인도", ConversationContext.SERMON))
        assertEquals("거룩한 영의 인도", ContextualTranslation.refine(
            "A sacred spirit", "거룩한 영의 인도", ConversationContext.SERMON))
    }

    @Test fun smallGroupTermCanBeCorrected() {
        assertEquals("서로 기도 제목을 나눠요.", ContextualTranslation.refine(
            "Let's share our prayer requests.", "우리의 기도 요청을 나눕시다.", ConversationContext.SMALL_GROUP))
    }

    @Test fun generalConversationIsUnchanged() {
        assertEquals("우리의 기도 요청을 나눕시다.", ContextualTranslation.refine(
            "Let's share our prayer requests.", "우리의 기도 요청을 나눕시다.", ConversationContext.GENERAL))
    }

    @Test fun labelsCoverTheThreeRequestedAccuracyLevels() {
        assertEquals(3, AccuracyLevel.entries.size)
        assertEquals(4, ConversationContext.entries.size)
    }
}
