package com.example.s23quicktranslate

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Private on-device storage. CSV is exported only on an explicit button press. */
class BenchmarkStore(context: Context) {
    private val file = AtomicFile(File(context.filesDir, "benchmark_trials_v10.json"))
    private val rows = mutableListOf<BenchmarkTrial>()

    init {
        try {
            val json = JSONArray(String(file.readFully(), Charsets.UTF_8))
            for (i in 0 until json.length()) {
                val o = json.getJSONObject(i)
                rows += BenchmarkTrial(
                    timestamp = o.optLong("timestamp"),
                    caseId = o.optString("caseId"),
                    condition = o.optString("condition"),
                    repetition = o.optInt("repetition", 1),
                    version = o.optString("version"),
                    accuracy = o.optString("accuracy"),
                    context = o.optString("context"),
                    english = o.optString("english"),
                    korean = o.optString("korean"),
                    englishChecked = o.optBoolean("englishChecked"),
                    koreanChecked = o.optBoolean("koreanChecked"),
                    quality = o.optInt("quality"),
                    firstEnglishMs = if (o.isNull("firstEnglishMs")) null else o.optLong("firstEnglishMs"),
                    firstKoreanMs = if (o.isNull("firstKoreanMs")) null else o.optLong("firstKoreanMs"),
                    capturedCount = o.optInt("capturedCount"),
                    transcriptIds = (o.optJSONArray("transcriptIds") ?: JSONArray()).let { a ->
                        (0 until a.length()).map { i -> a.optLong(i) } },
                    note = o.optString("note")
                )
            }
        } catch (_: Exception) { /* Empty on first launch, or a corrupt storage file. */ }
    }

    fun all(): List<BenchmarkTrial> = rows.toList()
    fun add(trial: BenchmarkTrial) {
        rows += trial
        try { persist() } catch (e: Exception) {
            rows.removeAt(rows.lastIndex)
            throw e
        }
    }
    fun updateAt(index: Int, trial: BenchmarkTrial) {
        if (index !in rows.indices) return
        val before = rows[index]
        rows[index] = trial
        try { persist() } catch (e: Exception) { rows[index] = before; throw e }
    }
    fun clear() {
        val before = rows.toList()
        rows.clear()
        try { persist() } catch (e: Exception) { rows.addAll(before); throw e }
    }

    private fun persist() {
        val data = JSONArray()
        for (r in rows) {
            data.put(JSONObject().apply {
                put("timestamp", r.timestamp)
                put("caseId", r.caseId)
                put("condition", r.condition)
                put("repetition", r.repetition)
                put("version", r.version)
                put("accuracy", r.accuracy)
                put("context", r.context)
                put("english", r.english)
                put("korean", r.korean)
                put("englishChecked", r.englishChecked)
                put("koreanChecked", r.koreanChecked)
                put("quality", r.quality)
                put("firstEnglishMs", r.firstEnglishMs ?: JSONObject.NULL)
                put("firstKoreanMs", r.firstKoreanMs ?: JSONObject.NULL)
                put("capturedCount", r.capturedCount)
                put("transcriptIds", JSONArray(r.transcriptIds))
                put("note", r.note)
            })
        }
        val stream = file.startWrite()
        try {
            stream.write(data.toString().toByteArray(Charsets.UTF_8))
            file.finishWrite(stream)
        } catch (e: Exception) {
            file.failWrite(stream)
            throw e
        }
    }

    /** UTF-8 with BOM for Excel; every field is RFC 4180 quoted. */
    fun csv(): String {
        val keys = listOf("savedAtEpochMs", "appVersion", "condition", "repeat", "id", "group",
            "referenceEnglish", "recognizedEnglish", "referenceKorean", "translatedKorean",
            "werErrors", "referenceWords", "werPercent", "englishChecked", "koreanChecked",
            "quality1to5", "firstEnglishMsFromArm", "firstKoreanMsFromArm", "capturedSegments",
            "falsePositive", "accuracyMode", "conversationContext", "transcriptIds", "note")
        fun escape(value: Any?): String = "\"" + (value?.toString() ?: "").replace("\"", "\"\"") + "\""
        val sb = StringBuilder("\uFEFF")
        sb.append(keys.joinToString(",") { escape(it) }).append("\r\n")
        for (r in rows) {
            val c = r.testCase
            val w = r.wordScore
            val fields = listOf(r.timestamp, r.version, r.condition, r.repetition, r.caseId,
                c?.group, c?.referenceEnglish, r.english, c?.referenceKorean, r.korean,
                w?.errors, w?.referenceWords, w?.let { "%.2f".format(java.util.Locale.US, it.werPercent) },
                r.englishChecked, r.koreanChecked, r.quality.takeIf { it in 1..5 },
                r.firstEnglishMs, r.firstKoreanMs, r.capturedCount,
                r.falsePositive, r.accuracy, r.context, r.transcriptIds.joinToString(";"), r.note)
            sb.append(fields.joinToString(",") { escape(it) }).append("\r\n")
        }
        return sb.toString()
    }
}
