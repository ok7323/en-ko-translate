package com.example.s23quicktranslate

import android.app.Application
import android.os.StatFs
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.concurrent.Executors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Fast translation is an on-device ML Kit model; this does not claim GPU/NPU acceleration.
 *  Optional AI translation explicitly attempts Adreno GPU then falls back to CPU.
 */
enum class TranslationMode { FAST, GPU_AI }
enum class ComputeMode { GPU, CPU }

data class VoiceUiState(
    val mode: TranslationMode = TranslationMode.FAST,
    val settings: VoiceSettings = VoiceSettings(),
    val fastReady: Boolean = false,
    val fastPreparing: Boolean = false,
    val aiModelPresent: Boolean = false,
    val aiChecking: Boolean = true,
    val aiDownloading: Boolean = false,
    val aiLoading: Boolean = false,
    val aiReady: Boolean = false,
    val aiBackend: ComputeMode? = null,
    val downloadBytes: Long = 0,
    val totalBytes: Long = 0,
    val entries: List<TranscriptEntry> = emptyList(),
    val englishHistory: String = "",
    val koreanHistory: String = "",
    val englishPartial: String = "",
    val koreanPartial: String = "",
    val speedInfo: String = "",
    val status: String = "빠른 번역 모델을 준비해 주세요.",
    val error: String? = null
) {
    val readyForMic: Boolean get() = if (mode == TranslationMode.FAST)
        fastReady || (settings.accuracyLevel == AccuracyLevel.HIGH && aiReady) else aiReady
    val busy: Boolean get() = fastPreparing || aiDownloading || aiLoading
}

private data class PendingSegment(
    val text: String,
    val sequence: Long,
    val accuracy: AccuracyLevel,
    val situation: ConversationContext,
    val priorEnglish: String
)

class TranslatorViewModel(app: Application) : AndroidViewModel(app) {
    companion object {
        private const val MODEL_FILENAME = "qwen3_0.6b_nothink_q4_block32_ekv1280.litertlm"
        private const val MODEL_URL =
            "https://huggingface.co/litert-community/Qwen3-0.6B-int4/resolve/main/" + MODEL_FILENAME
        private const val MODEL_SHA256 =
            "2df6821ec12702dafd33915e7a1a1adc7c4b053f3672fd9555dfaf3a114c4139"
        private const val MIN_MODEL_BYTES = 300_000_000L
        private const val ESTIMATED_MODEL_BYTES = 347_000_000L
    }

    private val context = getApplication<Application>()
    private val modelFile = File(context.filesDir, MODEL_FILENAME)
    private val prefs = context.getSharedPreferences("model_validation", 0)
    private val executor = Executors.newSingleThreadExecutor()
    private val dispatcher = executor.asCoroutineDispatcher()
    private val worker = CoroutineScope(SupervisorJob() + dispatcher)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var options = VoiceSettings.load(context)
    private val transcriptStore = TranscriptStore(context.filesDir)
    private val transcriptEntries = transcriptStore.load().toMutableList()
    private val _state = MutableStateFlow(VoiceUiState(settings = options, entries = transcriptEntries.toList()))
    val state: StateFlow<VoiceUiState> = _state.asStateFlow()

    private val fastTranslator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.KOREAN)
            .build()
    )
    private val pendingSegments = ArrayDeque<PendingSegment>()
    private var translationRunning = false
    private var sequence = transcriptEntries.maxOfOrNull { it.id } ?: 0L
    private val englishDrafts = EnglishDraftLedger()
    private var previewRevision = 0L
    private var previewRunnable: Runnable? = null
    private var lastPreviewText = ""
    private var lastRawHypothesis = ""
    private var previewInFlight = false
    private var queuedPreview: String? = null
    private var previewStartedAt = 0L
    private var nextPreviewAt = 0L
    private var speechStartedAt = 0L
    private var firstPartialMs: Long? = null
    private var firstKoreanMs: Long? = null
    private var finalAsrMs: Long? = null
    private var finalTranslateMs: Long? = null

    private var engine: Engine? = null
    private var activeBackend: ComputeMode? = null

    init {
        // Recheck the fast model automatically only after the user previously opted in.
        // The GPU AI model is optional and never blocks the fast path startup.
        if (options.prewarmTranslation && prefs.getBoolean("fast_model_opt_in", false)) prepareFastModel()
        worker.launch {
            try {
                val present = verifyExistingModel()
                _state.update { it.copy(aiChecking = false, aiModelPresent = present) }
                if (present && options.accuracyLevel == AccuracyLevel.HIGH) activateAiEngine()
            } catch (e: Exception) {
                _state.update { it.copy(aiChecking = false, error = detail(e)) }
            }
        }
    }

    fun prepareFastModel() {
        val snapshot = _state.value
        if (snapshot.fastReady || snapshot.fastPreparing) return
        _state.update { it.copy(fastPreparing = true, error = null, status = "영어→한국어 모델 확인/다운로드 중…") }
        // No Wi-Fi requirement: the user explicitly requested the download.
        fastTranslator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                prefs.edit().putBoolean("fast_model_opt_in", true).apply()
                _state.update {
                    it.copy(fastReady = true, fastPreparing = false,
                        status = "빠른 번역 준비 완료 · 마이크를 눌러 영어를 들려주세요.")
                }
            }
            .addOnFailureListener { err ->
                _state.update { it.copy(fastPreparing = false, status = "번역 모델 준비 실패", error = detail(err)) }
            }
    }

    fun selectMode(mode: TranslationMode) {
        val s = _state.value
        if (s.busy || s.mode == mode) return
        // Drop old previews. Previously finalized segments still finish in their selected mode.
        invalidatePreview()
        _state.update {
            it.copy(mode = mode, koreanPartial = "", status = if (mode == TranslationMode.FAST)
                "빠른 번역 모드 · 기기 내 ML Kit" else "AI 번역 모드 · GPU 우선, 실패 시 CPU")
        }
        if ((mode == TranslationMode.GPU_AI || options.accuracyLevel == AccuracyLevel.HIGH) &&
            s.aiModelPresent && !s.aiReady && !s.aiLoading) {
            worker.launch { activateAiEngine() }
        }
    }

    /** Settings are re-read on return from SettingsActivity. The queue remains intact. */
    fun applySettings(new: VoiceSettings) {
        val old = options
        if (old == new) return
        options = new
        invalidatePreview()
        _state.update { it.copy(
            settings = new,
            englishPartial = if (new.partialCaptions) it.englishPartial else "",
            koreanPartial = if (new.partialTranslation) it.koreanPartial else "",
            speedInfo = if (new.showMetrics) it.speedInfo else "") }
        if (new.prewarmTranslation && !old.prewarmTranslation &&
            prefs.getBoolean("fast_model_opt_in", false)) prepareFastModel()
        // "상" is an actual engine policy: when the optional AI model is installed, load it
        // for final-stage contextual translation. No silent downloads or false accuracy claim.
        if (new.accuracyLevel == AccuracyLevel.HIGH && old.accuracyLevel != AccuracyLevel.HIGH &&
            _state.value.aiModelPresent && !_state.value.aiReady && !_state.value.aiLoading) {
            worker.launch { activateAiEngine() }
        }
        if (old.preferGpuForAi != new.preferGpuForAi && engine != null) {
            _state.update { it.copy(aiReady = false, aiLoading = true) }
            worker.launch {
                try { engine?.close() } catch (_: Exception) { }
                engine = null
                activeBackend = null
                if ((_state.value.mode == TranslationMode.GPU_AI ||
                        options.accuracyLevel == AccuracyLevel.HIGH) && _state.value.aiModelPresent) activateAiEngine()
                else _state.update { it.copy(aiReady = false, aiLoading = false, aiBackend = null) }
            }
        }
        updateMetrics()
    }

    /** The clock starts at the recognizer's beginning-of-speech callback. */
    fun onSpeechStarted() {
        speechStartedAt = if (options.showMetrics) SystemClock.elapsedRealtime() else 0L
        firstPartialMs = null
        firstKoreanMs = null
        finalAsrMs = null
        finalTranslateMs = null
        lastRawHypothesis = ""
        previewStartedAt = 0L
        updateMetrics()
    }

    fun onSpeechEnded() {
        // At the endpoint there may have been only ONE partial hypothesis. The normal
        // stable-prefix method needs repeated partials, so explicitly preview the full
        // recognized phrase here while we wait briefly for the official final.
        if (options.partialTranslation && _state.value.fastReady &&
            _state.value.mode == TranslationMode.FAST && lastRawHypothesis.isNotBlank()) {
            queuedPreview = lastRawHypothesis
            previewRevision++
            schedulePreview(0L)
        }
    }

    /** Partial recognition is untrusted and can be revised. We translate only the newest hypothesis. */
    fun onEnglishPartial(text: String) {
        val raw = text.trim().take(800)
        if (raw.isBlank()) return
        // This path NEVER depends on the Korean translator, previews or caption checkboxes.
        // Even ONE partial result is immediately visible and, if enabled, persisted.
        englishDrafts.partial(raw) { ++sequence }?.let(::applyEnglishChange)
        if (options.showMetrics && firstPartialMs == null && speechStartedAt > 0L) {
            firstPartialMs = SystemClock.elapsedRealtime() - speechStartedAt
            updateMetrics()
        }
        if (options.skipDuplicateResults && raw == lastRawHypothesis) return
        val previous = lastRawHypothesis
        lastRawHypothesis = raw
        _state.update { it.copy(englishPartial = if (options.partialCaptions) raw else "") }
        if (!options.partialTranslation || !_state.value.fastReady || _state.value.mode != TranslationMode.FAST) {
            invalidatePreview()
            return
        }
        val stable = if (options.stablePrefix) StableSpeech.unchangedPrefix(previous, raw) else raw
        // A single recognizer partial (e.g. "Hello, hello") has no common prefix yet.
        // Debounce the entire hypothesis rather than never producing any Korean at all.
        val textToTranslate = stable.ifBlank { raw }
        if (textToTranslate.length < 2 || textToTranslate == lastPreviewText) return
        // Do not start previews while a finalized sentence is being translated.
        queuedPreview = textToTranslate
        previewRevision++
        val now = SystemClock.elapsedRealtime()
        val delay = if (nextPreviewAt == 0L) effectivePreviewMs().toLong()
            else (nextPreviewAt - now).coerceAtLeast(0L)
        // If the stability checkbox is on, wait longer for a one-shot hypothesis.
        schedulePreview(if (options.stablePrefix && stable.isBlank()) delay.coerceAtLeast(500L) else delay)
    }

    private fun effectivePreviewMs(): Int = when (options.accuracyLevel) {
        AccuracyLevel.LOW -> options.previewDebounceMs.coerceAtMost(150)
        AccuracyLevel.MEDIUM -> options.previewDebounceMs
        AccuracyLevel.HIGH -> options.previewDebounceMs.coerceAtLeast(350)
    }

    private fun schedulePreview(delayMs: Long) {
        previewRunnable?.let(mainHandler::removeCallbacks)
        previewRunnable = null
        if (!options.partialTranslation || previewInFlight || translationRunning || pendingSegments.isNotEmpty()) return
        val text = queuedPreview ?: return
        if (text == lastPreviewText || text.isBlank()) return
        val task = Runnable {
            previewRunnable = null
            if (!options.partialTranslation || _state.value.mode != TranslationMode.FAST ||
                !_state.value.fastReady || previewInFlight || translationRunning || pendingSegments.isNotEmpty()) return@Runnable
            val candidate = queuedPreview ?: return@Runnable
            queuedPreview = null
            if (candidate == lastPreviewText) return@Runnable
            lastPreviewText = candidate
            nextPreviewAt = SystemClock.elapsedRealtime() + effectivePreviewMs()
            val requestRevision = previewRevision
            val requestStarted = SystemClock.elapsedRealtime()
            previewInFlight = true
            fastTranslator.translate(candidate)
                .addOnSuccessListener { korean ->
                    if (requestRevision == previewRevision && options.partialTranslation &&
                        _state.value.mode == TranslationMode.FAST && !translationRunning) {
                        val display = if (options.accuracyLevel == AccuracyLevel.LOW) korean
                            else ContextualTranslation.refine(candidate, korean, options.conversationContext)
                        _state.update { it.copy(koreanPartial = display) }
                        if (options.showMetrics && firstKoreanMs == null && speechStartedAt > 0L) {
                            firstKoreanMs = SystemClock.elapsedRealtime() - speechStartedAt
                        }
                        if (options.showMetrics) previewStartedAt = SystemClock.elapsedRealtime() - requestStarted
                        updateMetrics()
                    }
                }
                .addOnFailureListener { /* A hypothesis is speculative; final results are retried. */ }
                .addOnCompleteListener {
                    previewInFlight = false
                    if (queuedPreview != null && options.partialTranslation) schedulePreview(effectivePreviewMs().toLong())
                }
        }
        previewRunnable = task
        mainHandler.postDelayed(task, delayMs.coerceAtLeast(0L))
    }

    private fun invalidatePreview() {
        previewRevision++
        queuedPreview = null
        previewRunnable?.let(mainHandler::removeCallbacks)
        previewRunnable = null
        lastPreviewText = ""
        nextPreviewAt = 0L
    }

    private fun updateMetrics() {
        if (!options.showMetrics) {
            _state.update { if (it.speedInfo.isEmpty()) it else it.copy(speedInfo = "") }
            return
        }
        val parts = listOfNotNull(
            firstPartialMs?.let { "첫 영어 인식 ${it}ms" },
            firstKoreanMs?.let { "첫 한국어 ${it}ms" },
            finalAsrMs?.let { "영어 확정 ${it}ms" },
            finalTranslateMs?.let { "최종 번역 ${it}ms" },
            previewStartedAt.takeIf { it > 0L }?.let { "미리 번역 연산 ${it}ms" },
        )
        _state.update { it.copy(speedInfo = parts.joinToString(" · ")) }
    }

    /** The English portion is written first, even when translation is not ready or fails. */
    private fun applyEnglishChange(change: EnglishRecordChange) {
        val index = transcriptEntries.indexOfFirst { it.id == change.id }
        val draft = change.action == EnglishRecordAction.ADD_DRAFT ||
            change.action == EnglishRecordAction.REVISE_DRAFT
        if (index < 0) {
            val entry = TranscriptEntry(change.id, System.currentTimeMillis(),
                change.english, draft = draft)
            transcriptEntries.add(entry)
            if (options.saveTranscriptToDevice) transcriptStore.add(entry)
        } else {
            val entry = transcriptEntries[index].copy(english = change.english, draft = draft)
            transcriptEntries[index] = entry
            if (options.saveTranscriptToDevice) transcriptStore.englishChanged(entry)
        }
        _state.update { it.copy(entries = transcriptEntries.toList()) }
    }

    /** Seal an already visible English draft, or append a final-only recognizer result. */
    fun onEnglishFinal(text: String) {
        val change = englishDrafts.final(text) { ++sequence } ?: run {
            clearPartial()
            return
        }
        val now = SystemClock.elapsedRealtime()
        finalAsrMs = if (options.showMetrics && speechStartedAt > 0L) now - speechStartedAt else null
        invalidatePreview()
        lastRawHypothesis = ""
        // A draft is already in history: exclude it from the prior sentence context.
        val priorEnglish = transcriptEntries.filter { it.id != change.id }
            .takeLast(2).joinToString(" ") { it.english }.takeLast(500)
        applyEnglishChange(change)
        _state.update { it.copy(englishPartial = "", koreanPartial = "") }
        pendingSegments.addLast(PendingSegment(change.english, change.id,
            options.accuracyLevel, options.conversationContext, priorEnglish))
        updateMetrics()
        processNextSegment()
    }

    /** Complete the most recent hypothesis if the recognizer sends no final callback. */
    fun finalizeEnglishDraft(): Boolean {
        if (!englishDrafts.hasDraft) return false
        onEnglishFinal("")
        return true
    }

    fun clearPartial() {
        invalidatePreview()
        lastRawHypothesis = ""
        _state.update { it.copy(englishPartial = "", koreanPartial = "") }
    }

    fun clearTranscript() {
        // Do not cancel an in-flight engine call; discard its result by sequence number.
        sequence++
        clearBeforeSequence = sequence
        pendingSegments.clear()
        englishDrafts.reset()
        transcriptEntries.clear()
        transcriptStore.clear()
        clearPartial()
        speechStartedAt = 0L
        firstPartialMs = null
        firstKoreanMs = null
        finalAsrMs = null
        finalTranslateMs = null
        previewStartedAt = 0L
        _state.update { it.copy(entries = emptyList(), englishHistory = "", koreanHistory = "", speedInfo = "") }
    }

    private fun processNextSegment() {
        if (translationRunning || pendingSegments.isEmpty()) return
        val next = pendingSegments.removeFirst()
        translationRunning = true
        val snapshot = _state.value
        val runMode = snapshot.mode
        val start = SystemClock.elapsedRealtime()
        // "상" really routes through the optional AI engine when available, even if the
        // lightweight ML Kit mode is selected. With no downloaded model it falls back to
        // ML Kit + conservative domain corrections rather than blocking the microphone.
        val useAi = snapshot.aiReady &&
            (runMode == TranslationMode.GPU_AI || next.accuracy == AccuracyLevel.HIGH)
        if (useAi) {
            worker.launch {
                try {
                    val (translated, msFirst) = runAiTranslationWithFallback(next)
                    mainHandler.post {
                        finishSegment(next, translated, start,
                            "AI ${if (activeBackend == ComputeMode.GPU) "GPU" else "CPU"} · 첫 토큰 ${msFirst}ms")
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    mainHandler.post {
                        // If AI inference fails in automatic high-accuracy mode, continue
                        // translating with ML Kit rather than losing the recognized speech.
                        if (runMode == TranslationMode.FAST && _state.value.fastReady) {
                            fastTranslator.translate(next.text)
                                .addOnSuccessListener { fallback ->
                                    finishSegment(next, ContextualTranslation.refine(next.text,
                                        fallback, next.situation), start, "ML Kit · AI 오류 후 대체")
                                }
                                .addOnFailureListener { second -> failSegment(next, second) }
                        } else failSegment(next, e)
                    }
                }
            }
        } else if (runMode == TranslationMode.FAST && snapshot.fastReady) {
            fastTranslator.translate(next.text)
                .addOnSuccessListener { translated ->
                    val corrected = if (next.accuracy == AccuracyLevel.LOW) translated
                        else ContextualTranslation.refine(next.text, translated, next.situation)
                    finishSegment(next, corrected, start,
                        if (next.accuracy == AccuracyLevel.HIGH) "ML Kit · AI 미준비, 상황별 보정"
                        else "ML Kit · ${next.accuracy.label}")
                }
                .addOnFailureListener { e -> failSegment(next, e) }
        } else {
            failSegment(next, IllegalStateException("선택한 번역 모델을 먼저 준비해 주세요."))
        }
    }

    private fun finishSegment(segment: PendingSegment, korean: String, started: Long, backend: String) {
        if (segment.sequence < clearBeforeSequence) {
            translationRunning = false
            processNextSegment()
            return
        }
        updateRecord(segment.sequence, korean.trim(), false)
        finalTranslateMs = if (options.showMetrics) SystemClock.elapsedRealtime() - started else null
        _state.update { it.copy(status = "번역 완료 ($backend)", error = null) }
        translationRunning = false
        updateMetrics()
        processNextSegment()
    }

    private var clearBeforeSequence = 0L
    private fun failSegment(segment: PendingSegment, error: Throwable) {
        if (segment.sequence >= clearBeforeSequence) {
            updateRecord(segment.sequence, "[번역 실패] ${detail(error)}", true)
            _state.update { it.copy(error = detail(error)) }
        }
        translationRunning = false
        processNextSegment()
    }

    private fun updateRecord(id: Long, korean: String, failed: Boolean) {
        val index = transcriptEntries.indexOfFirst { it.id == id }
        if (index < 0) return
        val updated = transcriptEntries[index].copy(korean = korean, failed = failed)
        transcriptEntries[index] = updated
        if (options.saveTranscriptToDevice) transcriptStore.translated(updated)
        _state.update { it.copy(entries = transcriptEntries.toList()) }
    }

    fun exportTranscript(): String = transcriptEntries.mapIndexed { index, entry ->
        "${index + 1}. [${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(entry.timestamp))}]\nEN: ${entry.english}\nKO: ${entry.korean.ifEmpty { "(번역 대기 중)" }}"
    }.joinToString("\n\n")

    fun downloadAiModel() {
        val s = _state.value
        if (s.aiChecking || s.aiDownloading || s.aiModelPresent) return
        _state.update { it.copy(aiDownloading = true, status = "AI GPU 모델 다운로드 중…", error = null) }
        worker.launch {
            try {
                downloadWithResume()
                _state.update { it.copy(aiDownloading = false, aiModelPresent = true, status = "AI 모델 검증 완료") }
                if (_state.value.mode == TranslationMode.GPU_AI || options.accuracyLevel == AccuracyLevel.HIGH) activateAiEngine()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(aiDownloading = false, error = detail(e), status = "AI 모델 다운로드 실패") }
            }
        }
    }

    private fun activateAiEngine() {
        if (engine != null) {
            _state.update { it.copy(aiReady = true, aiLoading = false) }
            return
        }
        _state.update { it.copy(aiLoading = true, aiReady = false, status = "Adreno GPU 모델 불러오는 중…") }
        try {
            if (!options.preferGpuForAi) {
                loadEngine(ComputeMode.CPU)
            } else {
                try {
                    loadEngine(ComputeMode.GPU)
                } catch (gpuError: Exception) {
                    if (!options.aiCpuFallback) throw gpuError
                    loadEngine(ComputeMode.CPU)
                }
            }
            _state.update {
                it.copy(aiReady = true, aiLoading = false, aiBackend = activeBackend,
                    status = "AI 준비 완료 · ${if (activeBackend == ComputeMode.GPU) "Adreno GPU" else "CPU 실행"}")
            }
        } catch (e: Exception) {
            _state.update { it.copy(aiReady = false, aiLoading = false, status = "AI 실행 불가", error = detail(e)) }
        }
    }

    private suspend fun runAiTranslationWithFallback(segment: PendingSegment): Pair<String, Long> {
        return try {
            runAiTranslation(segment)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (activeBackend != ComputeMode.GPU || !options.aiCpuFallback) throw e
            engine?.close()
            engine = null
            activeBackend = null
            loadEngine(ComputeMode.CPU)
            _state.update { it.copy(aiBackend = ComputeMode.CPU, status = "GPU 추론 실패 · CPU로 전환") }
            runAiTranslation(segment)
        }
    }

    private suspend fun runAiTranslation(segment: PendingSegment): Pair<String, Long> {
        val currentEngine = checkNotNull(engine) { "AI 엔진을 불러올 수 없습니다." }
        val config = ConversationConfig(
            samplerConfig = SamplerConfig(topK = 1, topP = 1.0, temperature = 0.01),
            maxOutputToken = if (segment.accuracy == AccuracyLevel.HIGH) 512 else 256
        )
        val domain = ContextualTranslation.prompt(segment.situation)
        val previousContext = if (segment.accuracy == AccuracyLevel.HIGH && segment.priorEnglish.isNotBlank())
            "Previous English context (for disambiguation only; do NOT translate this): ${segment.priorEnglish}"
            else ""
        val prompt = """
            You are an accurate English-to-Korean interpreter.
            Situation: $domain
            $previousContext
            Translate ONLY the English speech below to natural Korean. Preserve its actual meaning,
            names, numbers, scripture references and speaker intent. Do not add explanations,
            invent facts, repeat previous context, or answer the speaker's questions.
            Current English speech: ${segment.text}
            Korean translation:
        """.trimIndent()
        val start = SystemClock.elapsedRealtime()
        var first = -1L
        val out = StringBuilder()
        currentEngine.createConversation(config).use { conversation ->
            conversation.sendMessageAsync(prompt).collect { chunk ->
                val part = chunk.toString()
                if (part.isNotEmpty()) {
                    if (first < 0) first = SystemClock.elapsedRealtime() - start
                    out.append(part)
                }
            }
        }
        return out.toString().trim().removePrefix("한국어:").removePrefix("번역:").trim() to first
    }

    private fun loadEngine(mode: ComputeMode) {
        val candidate = Engine(
            EngineConfig(modelPath = modelFile.absolutePath,
                backend = if (mode == ComputeMode.GPU) Backend.GPU() else Backend.CPU(),
                cacheDir = context.cacheDir.absolutePath)
        )
        candidate.initialize()
        engine = candidate
        activeBackend = mode
    }

    private fun verifyExistingModel(): Boolean {
        if (!modelFile.isFile || modelFile.length() < MIN_MODEL_BYTES) return false
        val cached = prefs.getBoolean("verified", false) &&
            prefs.getLong("length", -1) == modelFile.length()
        if (cached) return true
        if (sha256(modelFile) != MODEL_SHA256) return false
        saveVerified()
        return true
    }

    private fun downloadWithResume() {
        val partial = File(context.filesDir, "$MODEL_FILENAME.part")
        if (partial.length() > 450_000_000L) partial.delete()
        val existing = if (partial.exists()) partial.length() else 0L
        val required = (ESTIMATED_MODEL_BYTES - existing + 60_000_000L).coerceAtLeast(60_000_000L)
        require(StatFs(context.filesDir.absolutePath).availableBytes > required) {
            "저장 공간 부족 · ${required / 1_000_000}MB 이상 필요"
        }
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 45_000
        conn.setRequestProperty("Accept-Encoding", "identity")
        if (existing > 0) conn.setRequestProperty("Range", "bytes=$existing-")
        try {
            val code = conn.responseCode
            require(code == 200 || code == 206) { "다운로드 HTTP $code" }
            val append = existing > 0 && code == 206
            val initial = if (append) existing else 0L
            val total = if (conn.contentLengthLong > 0) initial + conn.contentLengthLong
                else ESTIMATED_MODEL_BYTES
            var nBytes = initial
            var last = 0L
            conn.inputStream.use { input ->
                FileOutputStream(partial, append).use { output ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        nBytes += count
                        val now = SystemClock.elapsedRealtime()
                        if (now - last > 120) {
                            _state.update { it.copy(downloadBytes = nBytes, totalBytes = total) }
                            last = now
                        }
                    }
                    output.fd.sync()
                }
            }
        } finally {
            conn.disconnect()
        }
        require(partial.length() >= MIN_MODEL_BYTES) { "다운로드가 완료되지 않았습니다." }
        require(sha256(partial) == MODEL_SHA256) {
            partial.delete()
            "AI 모델 무결성 검사 실패 · 다시 다운로드하세요."
        }
        if (modelFile.exists()) modelFile.delete()
        check(partial.renameTo(modelFile)) { "AI 모델 파일을 저장할 수 없습니다." }
        saveVerified()
    }

    private fun saveVerified() {
        prefs.edit().putBoolean("verified", true).putLong("length", modelFile.length()).apply()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(512 * 1024).use { input ->
            val buf = ByteArray(512 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun detail(e: Throwable) = (e.message ?: e.javaClass.simpleName).take(180)

    override fun onCleared() {
        clearPartial()
        fastTranslator.close()
        transcriptStore.close()
        worker.launch {
            try { engine?.close() } finally {
                dispatcher.close()
                executor.shutdown()
            }
        }
        // Closing the worker in its queue keeps native Engine access single-threaded.
        super.onCleared()
    }
}
