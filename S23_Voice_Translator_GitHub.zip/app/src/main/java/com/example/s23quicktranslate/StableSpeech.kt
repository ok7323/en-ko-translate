package com.example.s23quicktranslate

/** Token-boundary stable prefix across consecutive ASR partial hypotheses.
 *  It intentionally omits the changing last token, which can be inaccurate.
 */
object StableSpeech {
    fun unchangedPrefix(previous: String, current: String): String {
        val a = words(previous)
        val b = words(current)
        if (a.isEmpty() || b.isEmpty()) return ""
        var count = 0
        while (count < a.size && count < b.size && a[count].equals(b[count], ignoreCase = true)) count++
        // Require at least two words to avoid translating a context-free fragment.
        return if (count >= 2) b.take(count).joinToString(" ") else ""
    }
    private fun words(text: String) = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
}
