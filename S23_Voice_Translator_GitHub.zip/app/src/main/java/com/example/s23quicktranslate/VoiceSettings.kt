package com.example.s23quicktranslate

import android.content.Context

/** Every switch is persisted. A disabled switch must not activate its corresponding pipeline feature. */
data class VoiceSettings(
    val accuracyLevel: AccuracyLevel = AccuracyLevel.MEDIUM,
    val conversationContext: ConversationContext = ConversationContext.GENERAL,
    val continuousListening: Boolean = true,
    val partialCaptions: Boolean = true,
    val partialTranslation: Boolean = true,
    val stablePrefix: Boolean = true,
    val segmentedRecognition: Boolean = false,
    val shortSilenceEndpoint: Boolean = false,
    val fastRestart: Boolean = true,
    val keepRecognizerWarm: Boolean = true,
    val prewarmTranslation: Boolean = true,
    val skipDuplicateResults: Boolean = true,
    val showMetrics: Boolean = true,
    val preferGpuForAi: Boolean = true,
    val aiCpuFallback: Boolean = true,
    val previewDebounceMs: Int = 200,
) {
    companion object {
        private const val PREF_NAME = "voice_options_v3"
        fun load(context: Context): VoiceSettings {
            val p = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val d = VoiceSettings()
            return d.copy(
                accuracyLevel = runCatching { AccuracyLevel.valueOf(p.getString("accuracyLevel", d.accuracyLevel.name)!!) }.getOrDefault(d.accuracyLevel),
                conversationContext = runCatching { ConversationContext.valueOf(p.getString("conversationContext", d.conversationContext.name)!!) }.getOrDefault(d.conversationContext),
                continuousListening = p.getBoolean("continuousListening", d.continuousListening),
                partialCaptions = p.getBoolean("partialCaptions", d.partialCaptions),
                partialTranslation = p.getBoolean("partialTranslation", d.partialTranslation),
                stablePrefix = p.getBoolean("stablePrefix", d.stablePrefix),
                segmentedRecognition = p.getBoolean("segmentedRecognition", d.segmentedRecognition),
                shortSilenceEndpoint = p.getBoolean("shortSilenceEndpoint", d.shortSilenceEndpoint),
                fastRestart = p.getBoolean("fastRestart", d.fastRestart),
                keepRecognizerWarm = p.getBoolean("keepRecognizerWarm", d.keepRecognizerWarm),
                prewarmTranslation = p.getBoolean("prewarmTranslation", d.prewarmTranslation),
                skipDuplicateResults = p.getBoolean("skipDuplicateResults", d.skipDuplicateResults),
                showMetrics = p.getBoolean("showMetrics", d.showMetrics),
                preferGpuForAi = p.getBoolean("preferGpuForAi", d.preferGpuForAi),
                aiCpuFallback = p.getBoolean("aiCpuFallback", d.aiCpuFallback),
                previewDebounceMs = p.getInt("previewDebounceMs", d.previewDebounceMs).coerceIn(100, 600),
            )
        }
    }
    fun save(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit()
            .putString("accuracyLevel", accuracyLevel.name)
            .putString("conversationContext", conversationContext.name)
            .putBoolean("continuousListening", continuousListening)
            .putBoolean("partialCaptions", partialCaptions)
            .putBoolean("partialTranslation", partialTranslation)
            .putBoolean("stablePrefix", stablePrefix)
            .putBoolean("segmentedRecognition", segmentedRecognition)
            .putBoolean("shortSilenceEndpoint", shortSilenceEndpoint)
            .putBoolean("fastRestart", fastRestart)
            .putBoolean("keepRecognizerWarm", keepRecognizerWarm)
            .putBoolean("prewarmTranslation", prewarmTranslation)
            .putBoolean("skipDuplicateResults", skipDuplicateResults)
            .putBoolean("showMetrics", showMetrics)
            .putBoolean("preferGpuForAi", preferGpuForAi)
            .putBoolean("aiCpuFallback", aiCpuFallback)
            .putInt("previewDebounceMs", previewDebounceMs.coerceIn(100, 600))
            .apply()
    }
}
