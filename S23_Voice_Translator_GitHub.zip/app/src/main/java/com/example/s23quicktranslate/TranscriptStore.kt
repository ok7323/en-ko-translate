package com.example.s23quicktranslate

import org.json.JSONObject
import java.io.File
import java.util.LinkedHashMap
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/** A bilingual phrase is ONE record, even while its translation is pending. */
data class TranscriptEntry(
    val id: Long,
    val timestamp: Long,
    val english: String,
    val korean: String = "",
    val failed: Boolean = false
)

/** Local append-only JSONL journal. Written on a serial IO executor, never on the UI thread. */
class TranscriptStore(private val directory: File) {
    private val file = File(directory, "bilingual_transcript.jsonl")
    private val writes = Executors.newSingleThreadExecutor()

    fun load(): List<TranscriptEntry> {
        if (!file.exists()) return emptyList()
        val items = LinkedHashMap<Long, TranscriptEntry>()
        try {
            file.forEachLine { line ->
                try {
                    val json = JSONObject(line)
                    when (json.optString("type")) {
                        "add" -> {
                            val id = json.getLong("id")
                            items[id] = TranscriptEntry(id, json.getLong("time"), json.getString("english"))
                        }
                        "done", "fail" -> {
                            val id = json.getLong("id")
                            val old = items[id]
                            if (old != null) items[id] = old.copy(
                                korean = json.getString("korean"), failed = json.optString("type") == "fail")
                        }
                        "clear" -> items.clear()
                    }
                } catch (_: Exception) { /* keep all preceding valid entries */ }
            }
        } catch (_: Exception) { /* unreadable file should not prevent opening the app */ }
        return items.values.toList()
    }

    private fun record(json: JSONObject) {
        try {
            writes.execute {
                try {
                    directory.mkdirs()
                    file.appendText(json.toString() + "\n", Charsets.UTF_8)
                } catch (_: Exception) { /* UI continues even if storage is full */ }
            }
        } catch (_: RejectedExecutionException) { /* view model has closed */ }
    }

    fun add(entry: TranscriptEntry) {
        record(JSONObject().put("type", "add").put("id", entry.id)
            .put("time", entry.timestamp).put("english", entry.english))
    }

    fun translated(entry: TranscriptEntry) {
        record(JSONObject().put("type", if (entry.failed) "fail" else "done")
            .put("id", entry.id).put("korean", entry.korean))
    }

    /** Delete previous transcript bytes as well as removing them from the visible UI. */
    fun clear() {
        try {
            writes.execute {
                try { if (file.exists()) file.delete() } catch (_: Exception) { }
            }
        } catch (_: RejectedExecutionException) { }
    }

    fun close() { writes.shutdown() }
}
