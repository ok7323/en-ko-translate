package com.example.s23quicktranslate

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Recycles visible cards so hours of recorded conversation remain scrollable. */
class TranscriptAdapter : ListAdapter<TranscriptEntry, TranscriptAdapter.Holder>(DIFF) {
    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<TranscriptEntry>() {
            override fun areItemsTheSame(old: TranscriptEntry, new: TranscriptEntry) = old.id == new.id
            override fun areContentsTheSame(old: TranscriptEntry, new: TranscriptEntry) = old == new
        }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.recordLabel)
        val english: TextView = view.findViewById(R.id.recordEnglish)
        val korean: TextView = view.findViewById(R.id.recordKorean)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_transcript, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val entry = getItem(position)
        val clock = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(entry.timestamp))
        holder.label.text = "#${position + 1} · $clock"
        holder.english.text = entry.english
        holder.korean.text = if (entry.korean.isBlank()) "번역 중…" else entry.korean
        holder.korean.alpha = if (entry.korean.isBlank()) 0.55f else 1.0f
    }
}
