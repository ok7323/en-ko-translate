package com.example.s23quicktranslate

/** Relative noise-floor gate for SpeechRecognizer.onRmsChanged().
 * onRmsChanged is optional and its values are NOT calibrated dB SPL. The gate can
 * only screen speech hypotheses based on observed level changes, not classify
 * white noise spectrally. If the recognition service emits no RMS samples,
 * speech hypotheses remain eligible so captions do not become unusable.
 */
enum class NoiseFilterLevel(val label: String, val margin: Float, val quietMs: Long) {
    GENTLE("약하게", 1.8f, 1500L),
    NORMAL("보통 (권장)", 2.6f, 1200L),
    STRONG("강하게", 3.7f, 1050L)
}

class AdaptiveNoiseGate(private val enabled: Boolean, private val level: NoiseFilterLevel) {
    private var floor: Float? = null
    private var readings = 0
    private var sustainedRise = 0
    private var lastVoiceMs = -1L
    var voiceDetected: Boolean = false
        private set

    fun sample(rms: Float, nowMs: Long) {
        if (!enabled || !rms.isFinite()) return
        readings++
        val previousFloor = floor
        if (previousFloor == null) {
            floor = rms
            return
        }
        // The noise floor follows drops quickly, but rises very slowly.
        // This avoids treating a steady fan or a persistent hiss as speech.
        val currentFloor = if (rms < previousFloor) rms else
            previousFloor + (rms - previousFloor) * 0.012f
        floor = currentFloor
        val aboveNoise = rms >= currentFloor + level.margin && rms >= 1.5f
        if (aboveNoise) {
            sustainedRise++
            if (sustainedRise >= 2) {
                voiceDetected = true
                lastVoiceMs = nowMs
            }
        } else {
            sustainedRise = 0
        }
    }

    fun acceptsText(): Boolean = !enabled || readings < 3 || voiceDetected

    fun silenceConfirmed(nowMs: Long): Boolean = enabled && voiceDetected &&
        lastVoiceMs >= 0L && nowMs - lastVoiceMs >= level.quietMs

    fun rmsAvailable(): Boolean = readings >= 3
}
