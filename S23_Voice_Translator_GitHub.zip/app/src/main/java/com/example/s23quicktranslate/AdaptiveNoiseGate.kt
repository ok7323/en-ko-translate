package com.example.s23quicktranslate

/** Optional RMS-based SILENCE BOUNDARY helper (not a recognition gate).
 * onRmsChanged is service-specific and may be absent or poorly correlated with
 * speech recognition quality. RMS must NEVER decide whether text delivered by
 * the Android speech recognizer is displayed or recorded. This helper only
 * suggests a segment boundary after an observed increase followed by silence.
 * This is NOT spectral noise suppression or a voice activity classifier.
 */
enum class NoiseFilterLevel(val label: String, val margin: Float, val quietMs: Long) {
    GENTLE("약하게", 1.8f, 1500L),
    NORMAL("보통 (권장)", 2.6f, 1200L),
    STRONG("강하게", 3.7f, 1050L)
}

class AdaptiveNoiseGate(private val enabled: Boolean, private val level: NoiseFilterLevel) {
    private var floor: Float? = null
    private var readings = 0
    private var sustainedRise = 0
    private var lastVoiceMs = -1L
    var voiceDetected: Boolean = false
        private set

    fun sample(rms: Float, nowMs: Long) {
        if (!enabled || !rms.isFinite()) return
        readings++
        val previousFloor = floor
        if (previousFloor == null) {
            floor = rms
            return
        }
        // The noise floor follows drops quickly, but rises very slowly.
        // This avoids treating a steady fan or a persistent hiss as speech.
        val currentFloor = if (rms < previousFloor) rms else
            previousFloor + (rms - previousFloor) * 0.012f
        floor = currentFloor
        val aboveNoise = rms >= currentFloor + level.margin && rms >= 1.5f
        if (aboveNoise) {
            sustainedRise++
            if (sustainedRise >= 2) {
                voiceDetected = true
                lastVoiceMs = nowMs
            }
        } else {
            sustainedRise = 0
        }
    }

    /** Safety invariant: ASR text is never blocked by an acoustic RMS heuristic. */
    fun acceptsText(): Boolean = true

    fun silenceConfirmed(nowMs: Long): Boolean = enabled && voiceDetected &&
        lastVoiceMs >= 0L && nowMs - lastVoiceMs >= level.quietMs

    fun rmsAvailable(): Boolean = readings >= 3
}
