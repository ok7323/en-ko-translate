package com.example.s23quicktranslate

/** English must enter the history on the FIRST nonempty recognizer hypothesis.
 * A sequence of partial hypotheses edits the SAME card. A final result seals it.
 * This component is free of Android dependencies to test the exact lifecycle.
 */
enum class EnglishRecordAction { ADD_DRAFT, REVISE_DRAFT, FINALIZE_DRAFT, ADD_FINAL }

data class EnglishRecordChange(
    val id: Long,
    val english: String,
    val action: EnglishRecordAction
)

class EnglishDraftLedger {
    private var draftId: Long? = null
    private var draftEnglish: String = ""
    val hasDraft: Boolean get() = draftId != null

    fun partial(text: String, nextId: () -> Long): EnglishRecordChange? {
        val clean = text.trim().take(1200)
        if (clean.isBlank()) return null
        val id = draftId
        return if (id == null) {
            val newId = nextId()
            draftId = newId
            draftEnglish = clean
            EnglishRecordChange(newId, clean, EnglishRecordAction.ADD_DRAFT)
        } else if (draftEnglish != clean) {
            draftEnglish = clean
            EnglishRecordChange(id, clean, EnglishRecordAction.REVISE_DRAFT)
        } else null
    }

    fun final(text: String, nextId: () -> Long): EnglishRecordChange? {
        val clean = text.trim().take(1200).ifBlank { draftEnglish }
        val id = draftId
        draftId = null
        draftEnglish = ""
        if (clean.isBlank()) return null
        return if (id != null) EnglishRecordChange(id, clean, EnglishRecordAction.FINALIZE_DRAFT)
        else EnglishRecordChange(nextId(), clean, EnglishRecordAction.ADD_FINAL)
    }

    fun reset() {
        draftId = null
        draftEnglish = ""
    }
}
