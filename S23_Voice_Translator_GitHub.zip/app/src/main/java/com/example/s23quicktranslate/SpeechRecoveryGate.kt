package com.example.s23quicktranslate

/** Retains speech when an on-device recognizer reports partials but loses its final event.
 * This gate accepts one segment per ordinary recognizer session. Segmented sessions
 * call reset() between reported segments and are handled separately in MainActivity.
 */
class SpeechRecoveryGate {
    private var lastPartial = ""
    private var committed = false

    fun reset() {
        lastPartial = ""
        committed = false
    }

    fun onPartial(text: String) {
        if (!committed && text.isNotBlank()) lastPartial = text.trim()
    }

    /** Prefer the full result, even when its wording differs from the last hypothesis. */
    fun takeFinalOrPartial(finalText: String): String? {
        if (committed) return null
        committed = true
        return finalText.trim().ifBlank { lastPartial }.ifBlank { null }
    }

    /** Called only when a deadline expires, the session errors or the user stops. */
    fun takeFallback(): String? = takeFinalOrPartial("")
}
