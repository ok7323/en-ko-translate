package com.example.s23quicktranslate

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Spinner
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity

/** No decorative checkboxes: every setting has an actual consumer in MainActivity or ViewModel. */
class SettingsActivity : ComponentActivity() {
    private var options = VoiceSettings()
    private var updating = false

    private val switches = listOf(
        R.id.cbContinuous to "continuousListening",
        R.id.cbNoiseFilter to "noiseFilter",
        R.id.cbQuiet to "quietSpeechMode",
        R.id.cbBoost to "boostQuietInput",
        R.id.cbContextBias to "contextBiasing",
        R.id.cbPersist to "saveTranscriptToDevice",
        R.id.cbAutoFollow to "autoFollowTranscript",
        R.id.cbCaptions to "partialCaptions",
        R.id.cbLiveTranslate to "partialTranslation",
        R.id.cbStable to "stablePrefix",
        R.id.cbSegmented to "segmentedRecognition",
        R.id.cbSilence to "shortSilenceEndpoint",
        R.id.cbQuickRestart to "fastRestart",
        R.id.cbWarmRecognizer to "keepRecognizerWarm",
        R.id.cbPrewarm to "prewarmTranslation",
        R.id.cbDedupe to "skipDuplicateResults",
        R.id.cbMetrics to "showMetrics",
        R.id.cbGpu to "preferGpuForAi",
        R.id.cbCpuFallback to "aiCpuFallback"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        options = VoiceSettings.load(this)
        configureNoiseFilterLevel()
        switches.forEach { (id, key) ->
            val cb = findViewById<CheckBox>(id)
            cb.setOnCheckedChangeListener { _, checked ->
                if (!updating) {
                    options = when (key) {
                        "continuousListening" -> options.copy(continuousListening = checked)
                        "noiseFilter" -> options.copy(noiseFilter = checked)
                        "quietSpeechMode" -> options.copy(quietSpeechMode = checked)
                        "boostQuietInput" -> options.copy(boostQuietInput = checked)
                        "contextBiasing" -> options.copy(contextBiasing = checked)
                        "saveTranscriptToDevice" -> options.copy(saveTranscriptToDevice = checked)
                        "autoFollowTranscript" -> options.copy(autoFollowTranscript = checked)
                        "partialCaptions" -> options.copy(partialCaptions = checked)
                        "partialTranslation" -> options.copy(partialTranslation = checked)
                        "stablePrefix" -> options.copy(stablePrefix = checked)
                        "segmentedRecognition" -> options.copy(segmentedRecognition = checked)
                        "shortSilenceEndpoint" -> options.copy(shortSilenceEndpoint = checked)
                        "fastRestart" -> options.copy(fastRestart = checked)
                        "keepRecognizerWarm" -> options.copy(keepRecognizerWarm = checked)
                        "prewarmTranslation" -> options.copy(prewarmTranslation = checked)
                        "skipDuplicateResults" -> options.copy(skipDuplicateResults = checked)
                        "showMetrics" -> options.copy(showMetrics = checked)
                        "preferGpuForAi" -> options.copy(preferGpuForAi = checked)
                        "aiCpuFallback" -> options.copy(aiCpuFallback = checked)
                        else -> options
                    }
                    options.save(this)
                    refreshEnabled()
                }
            }
        }
        val seek = findViewById<SeekBar>(R.id.previewSeek)
        seek.max = 10 // 100, 150, ... 600 ms
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    options = options.copy(previewDebounceMs = 100 + progress * 50)
                    options.save(this@SettingsActivity)
                }
                findViewById<TextView>(R.id.debounceValue).text = "${100 + progress * 50}ms"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) = Unit
            override fun onStopTrackingTouch(bar: SeekBar?) = Unit
        })
        findViewById<Button>(R.id.resetButton).setOnClickListener {
            options = VoiceSettings()
            options.save(this)
            showOptions()
        }
        findViewById<Button>(R.id.doneButton).setOnClickListener { finish() }
        showOptions()
    }

    private fun configureNoiseFilterLevel() {
        val spinner = findViewById<Spinner>(R.id.noiseLevelSpinner)
        spinner.adapter = android.widget.ArrayAdapter(this,
            android.R.layout.simple_spinner_dropdown_item, NoiseFilterLevel.entries.map { it.label })
        spinner.setSelection(options.noiseFilterLevel.ordinal)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = NoiseFilterLevel.entries[position]
                if (!updating && selected != options.noiseFilterLevel) {
                    options = options.copy(noiseFilterLevel = selected)
                    options.save(this@SettingsActivity)
                }
            }
        }
    }

    private fun showOptions() {
        updating = true
        findViewById<Spinner>(R.id.noiseLevelSpinner).setSelection(options.noiseFilterLevel.ordinal)
        val values = mapOf(
            "continuousListening" to options.continuousListening,
            "noiseFilter" to options.noiseFilter,
            "quietSpeechMode" to options.quietSpeechMode,
            "boostQuietInput" to options.boostQuietInput,
            "contextBiasing" to options.contextBiasing,
            "saveTranscriptToDevice" to options.saveTranscriptToDevice,
            "autoFollowTranscript" to options.autoFollowTranscript,
            "partialCaptions" to options.partialCaptions,
            "partialTranslation" to options.partialTranslation,
            "stablePrefix" to options.stablePrefix,
            "segmentedRecognition" to options.segmentedRecognition,
            "shortSilenceEndpoint" to options.shortSilenceEndpoint,
            "fastRestart" to options.fastRestart,
            "keepRecognizerWarm" to options.keepRecognizerWarm,
            "prewarmTranslation" to options.prewarmTranslation,
            "skipDuplicateResults" to options.skipDuplicateResults,
            "showMetrics" to options.showMetrics,
            "preferGpuForAi" to options.preferGpuForAi,
            "aiCpuFallback" to options.aiCpuFallback,
        )
        switches.forEach { (id, key) -> findViewById<CheckBox>(id).isChecked = values[key] == true }
        findViewById<SeekBar>(R.id.previewSeek).progress = (options.previewDebounceMs - 100) / 50
        findViewById<TextView>(R.id.debounceValue).text = "${options.previewDebounceMs}ms"
        updating = false
        refreshEnabled()
    }

    private fun refreshEnabled() {
        findViewById<CheckBox>(R.id.cbStable).isEnabled = options.partialTranslation
        findViewById<SeekBar>(R.id.previewSeek).isEnabled = options.partialTranslation
        findViewById<CheckBox>(R.id.cbQuickRestart).isEnabled = options.continuousListening
        findViewById<CheckBox>(R.id.cbCpuFallback).isEnabled = options.preferGpuForAi
        findViewById<Spinner>(R.id.noiseLevelSpinner).isEnabled = options.noiseFilter
        // Avoid boosting environmental noise when the noise gate is selected.
        findViewById<CheckBox>(R.id.cbBoost).isEnabled = !options.noiseFilter
    }
}
