package com.example.s23quicktranslate

/** Quality is a processing policy, not a claimed accuracy percentage. */
enum class AccuracyLevel(val label: String) {
    HIGH("상 · 문맥 정확도 우선"),
    MEDIUM("중 · 균형 (권장)"),
    LOW("하 · 응답 속도 우선")
}

enum class ConversationContext(val label: String) {
    GENERAL("일반 대화"),
    INTERVIEW("인터뷰 · 면접"),
    SERMON("교회 설교"),
    SMALL_GROUP("소모임 대화")
}

