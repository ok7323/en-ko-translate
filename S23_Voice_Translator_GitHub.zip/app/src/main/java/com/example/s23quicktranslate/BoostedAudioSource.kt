package com.example.s23quicktranslate

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.os.ParcelFileDescriptor
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * Experimental PCM injection on Android 13+: record 16-kHz mono PCM, then
 * normalize quiet non-silent frames and stream the audio to SpeechRecognizer.
 * Requires EXTRA_AUDIO_SOURCE support in the installed recognition service.
 */
class BoostedAudioSource private constructor(
    private val recorder: AudioRecord,
    private val readEnd: ParcelFileDescriptor,
    private val writeEnd: ParcelFileDescriptor,
    private val gainControl: AutomaticGainControl?,
    private val callback: (Int) -> Unit
) {
    private val running = AtomicBoolean(false)
    private var thread: Thread? = null
    val descriptor: ParcelFileDescriptor get() = readEnd

    fun start(): Boolean {
        return try {
            recorder.startRecording()
            if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) return false
            running.set(true)
            thread = Thread({ pump() }, "QuietVoicePCM").apply { isDaemon = true; start() }
            true
        } catch (_: Exception) { false }
    }

    private fun pump() {
        val frame = ByteArray(3200) // 100ms of 16kHz signed PCM16 mono
        var reported = 0
        try {
            ParcelFileDescriptor.AutoCloseOutputStream(writeEnd).use { output ->
                while (running.get()) {
                    val length = recorder.read(frame, 0, frame.size, AudioRecord.READ_BLOCKING)
                    if (length <= 0) continue
                    val n = length and -2
                    if (n <= 0) continue
                    val count = n / 2
                    var energy = 0.0
                    for (i in 0 until count) {
                        val p = i * 2
                        val sample = ((frame[p + 1].toInt() shl 8) or (frame[p].toInt() and 0xff)).toShort().toInt()
                        energy += sample.toDouble() * sample
                    }
                    val rms = sqrt(energy / count)
                    // Do not aggressively amplify near-silence: it is usually background noise.
                    val gain = if (rms < 85.0) 1.0 else (2300.0 / rms).coerceIn(1.0, 3.0)
                    if (gain > 1.05) {
                        for (i in 0 until count) {
                            val p = i * 2
                            val sample = ((frame[p + 1].toInt() shl 8) or (frame[p].toInt() and 0xff)).toShort().toInt()
                            val boosted = (sample * gain).toInt().coerceIn(-32768, 32767)
                            frame[p] = boosted.toByte()
                            frame[p + 1] = (boosted shr 8).toByte()
                        }
                    }
                    output.write(frame, 0, n)
                    if (++reported >= 3) {
                        reported = 0
                        callback(((rms / 5000.0) * 100).toInt().coerceIn(0, 100))
                    }
                }
            }
        } catch (_: Exception) { /* Closing the pipe on session end is normal. */ }
    }

    fun close() {
        running.set(false)
        try { recorder.stop() } catch (_: Exception) { }
        try { readEnd.close() } catch (_: Exception) { }
        try { writeEnd.close() } catch (_: Exception) { }
        try { thread?.join(100) } catch (_: Exception) { }
        try { gainControl?.release() } catch (_: Exception) { }
        try { recorder.release() } catch (_: Exception) { }
        thread = null
    }

    companion object {
        fun create(callback: (Int) -> Unit): BoostedAudioSource? {
            val sampleRate = 16_000
            val minBytes = AudioRecord.getMinBufferSize(sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBytes <= 0) return null
            var audio: AudioRecord? = null
            var read: ParcelFileDescriptor? = null
            var write: ParcelFileDescriptor? = null
            var agc: AutomaticGainControl? = null
            return try {
                val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
                val instance = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                    .setAudioFormat(format).setBufferSizeInBytes(maxOf(minBytes * 2, 6400))
                    .build()
                audio = instance
                if (instance.state != AudioRecord.STATE_INITIALIZED) {
                    instance.release()
                    return null
                }
                val pair = ParcelFileDescriptor.createPipe()
                read = pair[0]
                write = pair[1]
                if (AutomaticGainControl.isAvailable()) {
                    agc = AutomaticGainControl.create(instance.audioSessionId)
                    try { agc?.enabled = true } catch (_: Exception) { }
                }
                BoostedAudioSource(instance, pair[0], pair[1], agc, callback)
            } catch (_: Exception) {
                try { agc?.release() } catch (_: Exception) { }
                try { audio?.release() } catch (_: Exception) { }
                try { read?.close() } catch (_: Exception) { }
                try { write?.close() } catch (_: Exception) { }
                null
            }
        }
    }
}
