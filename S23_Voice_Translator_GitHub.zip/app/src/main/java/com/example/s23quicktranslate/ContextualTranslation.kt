package com.example.s23quicktranslate

/**
 * Lightweight, deterministic context corrections for ML Kit results. ML Kit does not accept
 * a context prompt; only explicit English phrases may trigger conservative Korean corrections.
 * Never alter proper names, numbers, or arbitrary unrelated Korean text.
 */
object ContextualTranslation {
    fun refine(source: String, translated: String, context: ConversationContext): String {
        if (context == ConversationContext.GENERAL) return translated
        val normalized = source.lowercase().trim().replace(Regex("[.!?\\s]+$"), "").replace(Regex("\\s+"), " ")
        val exact = when (context) {
            ConversationContext.INTERVIEW -> mapOf(
                "tell me about yourself" to "자기소개를 부탁드립니다.",
                "what are your strengths" to "본인의 강점은 무엇인가요?",
                "what are your weaknesses" to "본인의 약점은 무엇인가요?"
            )
            ConversationContext.SERMON -> mapOf(
                "let us pray" to "함께 기도하겠습니다.",
                "let's pray" to "함께 기도하겠습니다."
            )
            ConversationContext.SMALL_GROUP -> mapOf(
                "let's share our prayer requests" to "서로 기도 제목을 나눠요.",
                "let us share our prayer requests" to "서로 기도 제목을 나눠요."
            )
            ConversationContext.GENERAL -> emptyMap()
        }
        exact[normalized]?.let { return it }

        // Apply term alternatives only if the matching English expression is present.
        var result = translated
        if (context == ConversationContext.SERMON || context == ConversationContext.SMALL_GROUP) {
            if (Regex("\\bprayer requests?\\b", RegexOption.IGNORE_CASE).containsMatchIn(source)) {
                result = result.replace(Regex("기도\\s*요청(들)?"), "기도 제목")
            }
            if (Regex("\\bholy spirit\\b", RegexOption.IGNORE_CASE).containsMatchIn(source)) {
                result = result.replace("거룩한 영", "성령").replace("성스러운 영", "성령")
            }
            if (Regex("\\bgospel\\b", RegexOption.IGNORE_CASE).containsMatchIn(source)) {
                result = result.replace("좋은 소식", "복음")
            }
        }
        if (context == ConversationContext.SMALL_GROUP &&
            Regex("\\bicebreaker\\b", RegexOption.IGNORE_CASE).containsMatchIn(source)) {
            result = result.replace("얼음 차단기", "아이스브레이킹").replace("아이스 브레이커", "아이스브레이킹")
        }
        return result
    }

    /** Prompt conditioning is only supported by the optional on-device AI translator. */
    fun prompt(context: ConversationContext): String = when (context) {
        ConversationContext.GENERAL -> "Natural everyday conversation."
        ConversationContext.INTERVIEW -> "Job interview or formal interview. Use polite Korean (존댓말), accurate business terms, and clear speaker intent."
        ConversationContext.SERMON -> "Christian church sermon. Use established Korean Christian vocabulary, e.g. grace=은혜, gospel=복음, Holy Spirit=성령, congregation=회중 or 성도, according to context. Preserve Bible references without adding citations."
        ConversationContext.SMALL_GROUP -> "Small-group conversation, possibly church fellowship. Use natural spoken Korean, distinguish speakers implicitly, and translate prayer requests=기도 제목 when used in church context."
    }
}
