package com.example.s23quicktranslate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

/** Microphone -> Android's *on-device only* English ASR -> offline Korean translation. */
class MainActivity : ComponentActivity() {
    private val vm: TranslatorViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var keepListening = false
    private var listeningSession = false
    private var restart: Runnable? = null
    private var lastError: String? = null
    private var modeUpdating = false
    private val offlineSpeechAvailable: Boolean by lazy {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
    }

    private lateinit var microphoneButton: Button
    private lateinit var speechSetupButton: Button
    private lateinit var fastPrepareButton: Button
    private lateinit var aiDownloadButton: Button
    private lateinit var modeGroup: RadioGroup
    private lateinit var listenStatus: TextView
    private lateinit var engineStatus: TextView
    private lateinit var englishText: TextView
    private lateinit var koreanText: TextView
    private lateinit var metrics: TextView
    private lateinit var downloadProgress: ProgressBar

    private val requestMicrophone = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startContinuousListening() else show("마이크 권한이 필요합니다.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        microphoneButton = findViewById(R.id.microphoneButton)
        speechSetupButton = findViewById(R.id.speechSetupButton)
        fastPrepareButton = findViewById(R.id.fastPrepareButton)
        aiDownloadButton = findViewById(R.id.aiDownloadButton)
        modeGroup = findViewById(R.id.modeGroup)
        listenStatus = findViewById(R.id.listenStatus)
        engineStatus = findViewById(R.id.engineStatus)
        englishText = findViewById(R.id.englishText)
        koreanText = findViewById(R.id.koreanText)
        metrics = findViewById(R.id.metricsText)
        downloadProgress = findViewById(R.id.downloadProgress)

        microphoneButton.setOnClickListener { toggleMicrophone() }
        speechSetupButton.setOnClickListener { requestSpeechModel() }
        fastPrepareButton.setOnClickListener { vm.prepareFastModel() }
        aiDownloadButton.setOnClickListener { vm.downloadAiModel() }
        findViewById<Button>(R.id.clearButton).setOnClickListener { vm.clearTranscript() }
        findViewById<Button>(R.id.copyButton).setOnClickListener {
            val korean = vm.state.value.koreanHistory
            if (korean.isNotBlank()) {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("Korean translation", korean))
                show("한국어 번역을 복사했습니다.")
            }
        }
        modeGroup.setOnCheckedChangeListener { _, id ->
            if (!modeUpdating) {
                // The microphone only runs while the foreground Activity is visible.
                stopContinuousListening()
                vm.selectMode(if (id == R.id.modeAi) TranslationMode.GPU_AI else TranslationMode.FAST)
            }
        }
        if (!offlineSpeechAvailable) {
            listenStatus.text = "오프라인 음성 인식 서비스가 없습니다. 기기 음성 인식 서비스를 확인하세요."
            microphoneButton.isEnabled = false
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: VoiceUiState) {
        modeUpdating = true
        if (s.mode == TranslationMode.FAST) modeGroup.check(R.id.modeFast)
        else modeGroup.check(R.id.modeAi)
        modeUpdating = false
        engineStatus.text = s.status + when {
            s.mode == TranslationMode.FAST -> "\n빠른 번역: ML Kit · 기기 내 모델 (GPU/NPU 강제 지정 없음)"
            s.aiBackend == ComputeMode.GPU -> "\n고급 번역: Adreno GPU (OpenCL)"
            s.aiBackend == ComputeMode.CPU -> "\n고급 번역: CPU (GPU 실패 시 자동 전환)"
            else -> "\n고급 번역: GPU 우선, 불가하면 CPU"
        }
        englishText.text = listOf(s.englishHistory, s.englishPartial.takeIf { it.isNotBlank() }?.let { "🎤 $it" })
            .filterNotNull().filter { it.isNotBlank() }.joinToString("\n").ifEmpty {
                "마이크 버튼을 누른 다음 영어로 말하세요."
            }
        koreanText.text = listOf(s.koreanHistory, s.koreanPartial.takeIf { it.isNotBlank() }?.let { "… $it" })
            .filterNotNull().filter { it.isNotBlank() }.joinToString("\n").ifEmpty {
                "인식된 영어가 한국어로 번역됩니다."
            }
        metrics.text = s.speedInfo.ifBlank { "말하는 도중 영어 자막 표시 · 짧게 멈추면 번역 확정" }
        val usingFast = s.mode == TranslationMode.FAST
        fastPrepareButton.visibility = if (usingFast && !s.fastReady) android.view.View.VISIBLE else android.view.View.GONE
        fastPrepareButton.isEnabled = !s.fastPreparing
        fastPrepareButton.text = if (s.fastPreparing) "한국어 번역 모델 준비 중…" else "빠른 번역 모델 다운로드 / 확인"
        aiDownloadButton.visibility = if (!usingFast && !s.aiModelPresent) android.view.View.VISIBLE else android.view.View.GONE
        aiDownloadButton.isEnabled = !s.aiDownloading && !s.aiChecking
        aiDownloadButton.text = if (s.aiDownloading) "AI 모델 다운로드 중…" else "고급 AI GPU 모델 다운로드 · 약 347MB"
        downloadProgress.visibility = if (s.aiDownloading) android.view.View.VISIBLE else android.view.View.GONE
        if (s.aiDownloading) {
            downloadProgress.progress = (s.downloadBytes * 100 / s.totalBytes.coerceAtLeast(1)).toInt().coerceIn(0, 100)
        }
        microphoneButton.isEnabled = offlineSpeechAvailable && (keepListening || s.readyForMic)
        microphoneButton.text = if (keepListening) "■ 듣기 중지" else "🎙 영어 듣기 시작"
        speechSetupButton.isEnabled = offlineSpeechAvailable && !keepListening
        modeGroup.isEnabled = !s.busy
        findViewById<Button>(R.id.copyButton).isEnabled = s.koreanHistory.isNotBlank()
        if (s.error != null && s.error != lastError) show(s.error)
        lastError = s.error
    }

    private fun toggleMicrophone() {
        if (keepListening) {
            stopContinuousListening()
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestMicrophone.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            startContinuousListening()
        }
    }

    private fun intentForEnglish() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
    }

    private fun createRecognizerIfNeeded(): Boolean {
        if (recognizer != null) return true
        if (!offlineSpeechAvailable) {
            listenStatus.text = "오프라인 영어 음성 인식 서비스가 설치되지 않았습니다."
            return false
        }
        return try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        listenStatus.text = "🎙 듣는 중 · 영어로 말해 주세요."
                    }
                    override fun onBeginningOfSpeech() { listenStatus.text = "영어를 듣고 있습니다…" }
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() { listenStatus.text = "문장을 처리하는 중…" }
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    override fun onPartialResults(results: Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (!text.isNullOrBlank()) vm.onEnglishPartial(text)
                    }
                    override fun onResults(results: Bundle?) {
                        listeningSession = false
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (!text.isNullOrBlank()) vm.onEnglishFinal(text) else vm.clearPartial()
                        if (keepListening) scheduleNextListen(260)
                        else listenStatus.text = "듣기가 중지되었습니다."
                    }
                    override fun onError(error: Int) {
                        listeningSession = false
                        vm.clearPartial()
                        if (!keepListening) return
                        when (error) {
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH ->
                                scheduleNextListen(450)
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT ->
                                scheduleNextListen(1200)
                            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
                            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> {
                                stopContinuousListening()
                                listenStatus.text = "영어 오프라인 음성 모델이 없습니다. '영어 음성 모델 받기'를 눌러주세요."
                            }
                            else -> {
                                stopContinuousListening()
                                listenStatus.text = "음성 인식 오류($error). 다시 시작해 주세요."
                            }
                        }
                    }
                })
            }
            true
        } catch (e: Exception) {
            listenStatus.text = "음성 인식 초기화 오류: ${e.message}"
            false
        }
    }

    private fun startContinuousListening() {
        if (!vm.state.value.readyForMic) {
            show("먼저 현재 번역 모드의 모델을 준비하세요.")
            return
        }
        if (!createRecognizerIfNeeded()) return
        keepListening = true
        microphoneButton.text = "■ 듣기 중지"
        startSpeechSession()
    }

    private fun startSpeechSession() {
        if (!keepListening || listeningSession) return
        try {
            listeningSession = true
            recognizer?.startListening(intentForEnglish())
        } catch (e: Exception) {
            listeningSession = false
            keepListening = false
            microphoneButton.text = "🎙 영어 듣기 시작"
            listenStatus.text = "마이크 시작 실패: ${e.message}"
        }
    }

    private fun scheduleNextListen(delayMs: Long) {
        restart?.let(handler::removeCallbacks)
        val next = Runnable { restart = null; if (keepListening) startSpeechSession() }
        restart = next
        handler.postDelayed(next, delayMs)
    }

    private fun stopContinuousListening() {
        keepListening = false
        restart?.let(handler::removeCallbacks)
        restart = null
        microphoneButton.text = "🎙 영어 듣기 시작"
        listenStatus.text = "듣기 중지 · 다시 누르면 시작합니다."
        if (listeningSession) {
            try { recognizer?.stopListening() } catch (_: Exception) { /* service may have died */ }
        }
    }

    private fun requestSpeechModel() {
        if (!createRecognizerIfNeeded()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                recognizer?.triggerModelDownload(intentForEnglish())
                listenStatus.text = "영어 오프라인 음성 모델 다운로드를 요청했습니다. 다운로드 후 다시 시작하세요."
            } catch (e: Exception) {
                listenStatus.text = "음성 모델 요청 불가: ${e.message}"
            }
        } else {
            listenStatus.text = "기기 설정에서 영어 오프라인 음성 인식 언어를 설치해 주세요."
        }
    }

    private fun show(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onStop() {
        // Do not claim background microphone capture: this Activity only listens in foreground.
        keepListening = false
        restart?.let(handler::removeCallbacks)
        restart = null
        try { recognizer?.cancel() } catch (_: Exception) {}
        listeningSession = false
        super.onStop()
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        super.onDestroy()
    }
}
