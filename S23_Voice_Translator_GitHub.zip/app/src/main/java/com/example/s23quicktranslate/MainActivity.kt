package com.example.s23quicktranslate

import android.app.AlertDialog
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.media.AudioFormat
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/** Foreground microphone -> guaranteed on-device platform ASR -> translation. */
class MainActivity : ComponentActivity() {
    private val vm: TranslatorViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private var settings = VoiceSettings()
    private var recognizer: SpeechRecognizer? = null
    private var keepListening = false
    private var listeningSession = false
    private var restart: Runnable? = null
    private var lastError: String? = null
    private var modeUpdating = false
    private val recordAdapter = TranscriptAdapter()
    private var lastRenderedEntries: List<TranscriptEntry>? = null
    private var soundReadings = 0
    private var highestRms = -10f
    private var boostedSource: BoostedAudioSource? = null
    private var boostedDisabledThisRun = false
    private var boostWatchdog: Runnable? = null
    private var heardSpeechThisSession = false
    private var segmentedTemporarilyDisabled = false
    private var hadSegmentThisSession = false
    private var consecutiveErrors = 0
    // Android services are allowed to return partial text and delay/omit final callbacks.
    // Recover a stalled utterance once, then restart the recognizer to keep the history moving.
    private val recovery = SpeechRecoveryGate()
    private var finalResultRescue: Runnable? = null
    private var idlePartialRescue: Runnable? = null
    private var recognizerEpoch = 0L
    private companion object {
        const val FINAL_RESULT_GRACE_MS = 1_600L
        const val PARTIAL_IDLE_GRACE_MS = 4_000L
    }
    private val offlineSpeechAvailable: Boolean by lazy {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
    }

    private lateinit var microphoneButton: Button
    private lateinit var speechSetupButton: Button
    private lateinit var fastPrepareButton: Button
    private lateinit var aiDownloadButton: Button
    private lateinit var modeGroup: RadioGroup
    private lateinit var listenStatus: TextView
    private lateinit var engineStatus: TextView
    private lateinit var profileStatus: TextView
    private lateinit var englishText: TextView
    private lateinit var koreanText: TextView
    private lateinit var metrics: TextView
    private lateinit var downloadProgress: ProgressBar
    private lateinit var recordList: RecyclerView
    private lateinit var recordCount: TextView
    private lateinit var audioLevel: ProgressBar
    private lateinit var audioHint: TextView

    private val exportDocument = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                    it.write(vm.exportTranscript())
                } ?: error("파일을 열지 못했습니다")
                show("영어·한국어 기록을 저장했습니다.")
            } catch (e: Exception) { show("저장 실패: ${e.message}") }
        }
    }

    private val requestMicrophone = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else show("마이크 권한을 허용해 주세요.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = VoiceSettings.load(this)
        setContentView(R.layout.activity_main)
        microphoneButton = findViewById(R.id.microphoneButton)
        speechSetupButton = findViewById(R.id.speechSetupButton)
        fastPrepareButton = findViewById(R.id.fastPrepareButton)
        aiDownloadButton = findViewById(R.id.aiDownloadButton)
        modeGroup = findViewById(R.id.modeGroup)
        listenStatus = findViewById(R.id.listenStatus)
        engineStatus = findViewById(R.id.engineStatus)
        profileStatus = findViewById(R.id.profileStatus)
        englishText = findViewById(R.id.englishText)
        koreanText = findViewById(R.id.koreanText)
        metrics = findViewById(R.id.metricsText)
        downloadProgress = findViewById(R.id.downloadProgress)
        recordList = findViewById(R.id.recordList)
        recordCount = findViewById(R.id.recordCount)
        audioLevel = findViewById(R.id.audioLevel)
        audioHint = findViewById(R.id.audioHint)
        recordList.layoutManager = LinearLayoutManager(this)
        recordList.adapter = recordAdapter
        findViewById<Button>(R.id.latestButton).setOnClickListener {
            if (recordAdapter.itemCount > 0) recordList.scrollToPosition(recordAdapter.itemCount - 1)
        }
        findViewById<Button>(R.id.exportButton).setOnClickListener {
            if (vm.state.value.entries.isEmpty()) show("저장할 대화 기록이 없습니다.")
            else exportDocument.launch("S23_통역기록_${System.currentTimeMillis()}.txt")
        }
        findViewById<Button>(R.id.advancedToggleButton).setOnClickListener { button ->
            val panel = findViewById<View>(R.id.advancedPanel)
            val expand = panel.visibility != View.VISIBLE
            panel.visibility = if (expand) View.VISIBLE else View.GONE
            (button as Button).text = if (expand) "번역 모델 · 고급 엔진 접기 ▴"
                else "번역 모델 · 고급 엔진 펼치기 ▾"
        }

        microphoneButton.setOnClickListener { toggleMicrophone() }
        speechSetupButton.setOnClickListener { requestSpeechModel() }
        fastPrepareButton.setOnClickListener { vm.prepareFastModel() }
        aiDownloadButton.setOnClickListener { vm.downloadAiModel() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            stopListening()
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("대화 기록 삭제")
                .setMessage("저장된 영어·한국어 기록 전체를 삭제하시겠습니까?")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제") { _, _ -> vm.clearTranscript() }
                .show()
        }
        findViewById<Button>(R.id.copyButton).setOnClickListener {
            val text = vm.exportTranscript()
            if (text.isNotBlank()) {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("Bilingual transcript", text))
                show("영어·한국어 대화 기록을 복사했습니다.")
            }
        }
        modeGroup.setOnCheckedChangeListener { _, id ->
            if (!modeUpdating) {
                stopListening()
                vm.selectMode(if (id == R.id.modeAi) TranslationMode.GPU_AI else TranslationMode.FAST)
            }
        }
        if (!offlineSpeechAvailable) {
            listenStatus.text = "기기 내 음성 인식 서비스가 없습니다. 음성 입력 서비스를 확인하세요."
            microphoneButton.isEnabled = false
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val newSettings = VoiceSettings.load(this)
        if (newSettings != settings) {
            stopListening()
            settings = newSettings
            segmentedTemporarilyDisabled = false
            if (!settings.keepRecognizerWarm) destroyRecognizer()
        }
        vm.applySettings(settings)
        if (settings.keepRecognizerWarm && offlineSpeechAvailable && hasMicPermission()) {
            createRecognizerIfNeeded() // Does not start recording.
        }
    }

    private fun render(s: VoiceUiState) {
        // English speech can always be recorded when ASR is available, even without
        // a downloaded Korean translation model. The model panel is optional.
        profileStatus.text = "정확도: ${s.settings.accuracyLevel.label}  ·  상황: ${s.settings.conversationContext.label}"
        modeUpdating = true
        modeGroup.check(if (s.mode == TranslationMode.FAST) R.id.modeFast else R.id.modeAi)
        modeUpdating = false
        val autoAi = s.mode == TranslationMode.FAST && s.settings.accuracyLevel == AccuracyLevel.HIGH && s.aiReady
        engineStatus.text = s.status +
            (if (!s.readyForMic) "\n영어 기록은 지금도 가능 · 한국어 번역은 모델 준비 후" else "") +
            (if (autoAi) "\n상 모드: AI 문맥 번역 사용 가능 (결과는 상황에 따라 다름)" else if (
            s.mode == TranslationMode.FAST && s.settings.accuracyLevel == AccuracyLevel.HIGH
        ) "\n상 모드: AI가 미준비되어 ML Kit 보정 번역 사용 중" else "") + when {
            autoAi -> "\n최종 번역: AI 문맥 번역 · 중간 결과: ML Kit 준비 시 표시"
            s.mode == TranslationMode.FAST -> "\n번역: ML Kit 온디바이스 · GPU/NPU 지정 불가"
            s.aiBackend == ComputeMode.GPU -> "\n고급 번역: Adreno GPU (OpenCL)"
            s.aiBackend == ComputeMode.CPU -> "\n고급 번역: CPU"
            !s.settings.preferGpuForAi -> "\n고급 번역: CPU 선택"
            else -> "\n고급 번역: GPU 우선${if (s.settings.aiCpuFallback) " → CPU 대체" else " (대체 꺼짐)"}"
        }
        englishText.text = s.englishPartial.ifBlank { "영어를 듣고 있습니다 · 확정 문장은 아래에 표시" }
        koreanText.text = s.koreanPartial.ifBlank { "중간 번역 대기 중 · 최종 번역은 아래에 기록" }
        if (s.entries !== lastRenderedEntries) {
            val follow = settings.autoFollowTranscript && !recordList.canScrollVertically(1)
            lastRenderedEntries = s.entries
            recordAdapter.submitList(s.entries) {
                if (follow && recordAdapter.itemCount > 0) {
                    recordList.scrollToPosition(recordAdapter.itemCount - 1)
                }
            }
        }
        recordCount.text = "대화 기록 ${s.entries.size}개"
        metrics.visibility = if (s.settings.showMetrics) View.VISIBLE else View.GONE
        metrics.text = s.speedInfo.ifBlank { "측정 대기 · 영어로 말하면 ASR/번역 지연을 표시합니다." }
        val usingFast = s.mode == TranslationMode.FAST
        fastPrepareButton.visibility = if (usingFast && !s.fastReady) View.VISIBLE else View.GONE
        fastPrepareButton.isEnabled = !s.fastPreparing
        fastPrepareButton.text = if (s.fastPreparing) "한국어 모델 준비 중…" else "빠른 번역 모델 다운로드 / 확인"
        aiDownloadButton.visibility = if (!usingFast && !s.aiModelPresent) View.VISIBLE else View.GONE
        aiDownloadButton.isEnabled = !s.aiDownloading && !s.aiChecking
        aiDownloadButton.text = if (s.aiDownloading) "AI 모델 다운로드 중…" else "고급 AI 모델 다운로드 · 약 347MB"
        downloadProgress.visibility = if (s.aiDownloading) View.VISIBLE else View.GONE
        if (s.aiDownloading) {
            downloadProgress.progress = (s.downloadBytes * 100 / s.totalBytes.coerceAtLeast(1)).toInt().coerceIn(0, 100)
        }
        microphoneButton.isEnabled = offlineSpeechAvailable
        microphoneButton.text = if (keepListening) "■ 듣기 중지" else "🎙 영어 듣기 시작"
        speechSetupButton.isEnabled = offlineSpeechAvailable && !keepListening
        modeGroup.isEnabled = !s.busy
        findViewById<Button>(R.id.copyButton).isEnabled = s.entries.isNotEmpty()
        findViewById<Button>(R.id.exportButton).isEnabled = s.entries.isNotEmpty()
        findViewById<Button>(R.id.clearButton).isEnabled = s.entries.isNotEmpty()
        if (s.error != null && s.error != lastError) show(s.error)
        lastError = s.error
    }

    private fun hasMicPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toggleMicrophone() {
        if (keepListening) stopListening()
        else if (!hasMicPermission()) requestMicrophone.launch(Manifest.permission.RECORD_AUDIO)
        else startListening()
    }

    private fun intentForEnglish() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
        // Even when on-screen partial captions are disabled, accept partial hypotheses
        // privately as a recovery path if this recognizer never supplies onResults().
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        if (Build.VERSION.SDK_INT >= 33 && settings.fastRestart) {
            putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_LATENCY)
        }
        if (settings.quietSpeechMode || settings.shortSilenceEndpoint ||
            (settings.segmentedRecognition && !segmentedTemporarilyDisabled)) {
            // Quiet voices frequently have pauses. This HINT lengthens the end-pointer,
            // not the actual microphone gain; recognizers are permitted to ignore it.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                when {
                    settings.quietSpeechMode -> 1800
                    settings.shortSilenceEndpoint -> 500
                    else -> 850
                })
            if (settings.quietSpeechMode) {
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1250)
            }
        }
        if (Build.VERSION.SDK_INT >= 33 && boostedSource != null) {
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, boostedSource!!.descriptor)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16_000)
        }
        if (Build.VERSION.SDK_INT >= 33 && settings.contextBiasing) {
            val hints = when (settings.conversationContext) {
                ConversationContext.GENERAL -> emptyList()
                ConversationContext.INTERVIEW -> listOf("interview", "qualifications", "experience", "teamwork", "leadership", "strengths", "weaknesses")
                ConversationContext.SERMON -> listOf("Jesus Christ", "Holy Spirit", "Scripture", "Gospel", "grace", "faith", "prayer", "disciples", "salvation", "God")
                ConversationContext.SMALL_GROUP -> listOf("small group", "prayer requests", "fellowship", "Bible study", "testimony", "reflection")
            }
            if (hints.isNotEmpty()) putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, ArrayList(hints))
        }
        if (Build.VERSION.SDK_INT >= 33 && settings.segmentedRecognition && !segmentedTemporarilyDisabled) {
            putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION,
                RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS)
        }
    }

    private fun createRecognizerIfNeeded(): Boolean {
        if (recognizer != null) return true
        if (!offlineSpeechAvailable) {
            listenStatus.text = "영어 오프라인 음성 인식 서비스가 없습니다."
            return false
        }
        return try {
            val epoch = ++recognizerEpoch
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        soundReadings = 0
                        highestRms = -10f
                        audioLevel.progress = 0
                        audioHint.text = when {
                            boostedSource != null -> "실험적 PCM 음량 증폭 · 기기 지원 시 적용"
                            settings.quietSpeechMode -> "작은 목소리 모드 · 마이크 방향으로 말해 주세요."
                            else -> "음성 레벨은 참고용이며 실제 마이크 증폭은 아닙니다."
                        }
                        listenStatus.text = "🎙 듣는 중 · 영어로 말해 주세요."
                    }
                    override fun onBeginningOfSpeech() {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        heardSpeechThisSession = true
                        cancelBoostWatchdog()
                        listenStatus.text = "영어를 듣고 있습니다…"
                        vm.onSpeechStarted()
                    }
                    override fun onRmsChanged(rmsdB: Float) {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        // Level comes from the recognition service and is not a calibrated dB meter.
                        val level = ((rmsdB + 2f) * 100f / 14f).toInt().coerceIn(0, 100)
                        audioLevel.progress = level
                        if (soundReadings++ < 30) highestRms = maxOf(highestRms, rmsdB)
                        if (soundReadings == 30 && highestRms < 1.2f) {
                            audioHint.text = "입력이 약해 보입니다. S23 마이크를 가까이 두고 주변 소음을 줄여 주세요."
                        }
                    }
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        // A segmented recognizer can report more segments before ending its session.
                        if (hadSegmentThisSession && settings.segmentedRecognition &&
                            !segmentedTemporarilyDisabled) return
                        listenStatus.text = "문장 확정 중… (지연 시 자동 기록)"
                        vm.onSpeechEnded()
                        scheduleFinalResultRescue()
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    override fun onPartialResults(results: Bundle?) {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        val text = firstResult(results)
                        if (text.isNotBlank()) {
                            recovery.onPartial(text)
                            heardSpeechThisSession = true
                            cancelBoostWatchdog()
                            // Record EVERY nonblank English hypothesis immediately,
                            // regardless of partial-caption and translation settings.
                            vm.onEnglishPartial(text)
                            // Also handles services that never call onEndOfSpeech().
                            scheduleIdlePartialRescue()
                        }
                    }
                    override fun onSegmentResults(segmentResults: Bundle) {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        val text = firstResult(segmentResults)
                        if (text.isNotBlank()) {
                            heardSpeechThisSession = true
                            cancelBoostWatchdog()
                            hadSegmentThisSession = true
                            cancelSpeechRescueTimers()
                            recovery.reset() // segmented results have their own boundaries
                            vm.onEnglishFinal(text)
                            consecutiveErrors = 0
                            if (!settings.continuousListening) {
                                stopListening()
                                listenStatus.text = "한 구간 인식 완료 · 마이크 중지"
                            } else {
                                listenStatus.text = "구간 인식 완료 · 계속 듣는 중"
                            }
                        }
                    }
                    override fun onEndOfSegmentedSession() {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        commitRecoveredPartial()
                        vm.finalizeEnglishDraft()
                        endSessionAndPossiblyRestart()
                    }
                    override fun onResults(results: Bundle?) {
                        if (epoch != recognizerEpoch || !listeningSession) return
                        cancelSpeechRescueTimers()
                        // Some services send a blank final, and some report only partials.
                        // Prefer the official final if present; otherwise save the last partial.
                        // Ignore aggregate finals if segment callbacks already saved the words.
                        if (!hadSegmentThisSession) {
                            val confirmed = recovery.takeFinalOrPartial(firstResult(results))
                            if (!confirmed.isNullOrBlank()) {
                                vm.onEnglishFinal(confirmed)
                                consecutiveErrors = 0
                            } else if (!vm.finalizeEnglishDraft()) vm.clearPartial()
                        } else {
                            // A provider may end a segmented session with an unfinished draft.
                            vm.finalizeEnglishDraft()
                        }
                        endSessionAndPossiblyRestart()
                    }
                    override fun onError(error: Int) {
                        if (epoch != recognizerEpoch || !keepListening || !listeningSession) return
                        cancelSpeechRescueTimers()
                        cancelBoostWatchdog()
                        val recovered = commitRecoveredPartial() || vm.finalizeEnglishDraft()
                        if (recovered) listenStatus.text = "마지막 영어 구간 복구·기록 완료"
                        if (boostedSource != null && (error == SpeechRecognizer.ERROR_AUDIO ||
                                error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_NO_MATCH)) {
                            boostedDisabledThisRun = true
                            audioHint.text = "PCM 입력 호환성/인식 오류 · 일반 마이크로 자동 전환"
                        }
                        boostedSource?.close()
                        boostedSource = null
                        listeningSession = false
                        if (!recovered) vm.clearPartial()
                        if (settings.segmentedRecognition && !segmentedTemporarilyDisabled &&
                            (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY)) {
                            segmentedTemporarilyDisabled = true
                            listenStatus.text = "구간 인식 미지원 가능 · 일반 인식으로 전환"
                        }
                        when (error) {
                            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
                            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> {
                                stopListening()
                                listenStatus.text = "영어 오프라인 모델이 없습니다. '영어 음성 모델 받기'를 누르세요."
                                return
                            }
                        }
                        if (!settings.continuousListening) {
                            stopListening()
                            listenStatus.text = "음성 인식 오류($error)"
                            return
                        }
                        // Silence is normal during a sermon/interview; never stop the
                        // long-running session merely due to consecutive empty phrases.
                        consecutiveErrors = if (recovered ||
                            error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_NO_MATCH) 0 else consecutiveErrors + 1
                        if (consecutiveErrors > 5) {
                            stopListening()
                            listenStatus.text = "음성 인식 오류가 반복돼 중단했습니다($error). 다시 시도해 주세요."
                            return
                        }
                        val delay = when (error) {
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> 180L
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> 650L
                            else -> 850L
                        }
                        recycleRecognizerIfNeeded()
                        scheduleNextListen(delay * consecutiveErrors.coerceAtMost(3))
                    }
                })
            }
            true
        } catch (e: Exception) {
            listenStatus.text = "음성 인식 초기화 오류: ${e.message}"
            false
        }
    }

    private fun firstResult(bundle: Bundle?): String = bundle
        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        ?.firstOrNull().orEmpty().trim()

    private fun startListening() {
        // English-first transcription works before ML Kit or the AI model is installed.
        if (!hasMicPermission()) {
            requestMicrophone.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!createRecognizerIfNeeded()) return
        consecutiveErrors = 0
        keepListening = true
        segmentedTemporarilyDisabled = false
        boostedDisabledThisRun = false
        microphoneButton.text = "■ 듣기 중지"
        startSpeechSession()
    }

    private fun startSpeechSession() {
        if (!keepListening || listeningSession) return
        if (!createRecognizerIfNeeded()) {
            stopListening()
            return
        }
        try {
            listeningSession = true
            cancelSpeechRescueTimers()
            vm.finalizeEnglishDraft() // Safety: don't orphan speech from the previous session.
            recovery.reset()
            hadSegmentThisSession = false
            heardSpeechThisSession = false
            if (Build.VERSION.SDK_INT >= 33 && settings.boostQuietInput && !boostedDisabledThisRun) {
                val input = BoostedAudioSource.create { level ->
                    handler.post { if (keepListening) audioLevel.progress = level }
                }
                if (input != null && input.start()) {
                    boostedSource = input
                    audioHint.text = "실험적 PCM 작은 소리 증폭 중 (지원되는 음성 인식기만)"
                } else {
                    input?.close()
                    boostedDisabledThisRun = true
                    audioHint.text = "PCM 증폭 시작 불가 · 일반 마이크 사용"
                }
            }
            recognizer?.startListening(intentForEnglish())
            if (boostedSource != null) scheduleBoostWatchdog()
        } catch (e: Exception) {
            listeningSession = false
            boostedSource?.close()
            boostedSource = null
            stopListening()
            listenStatus.text = "마이크 시작 실패: ${e.message}"
        }
    }

    /** Give the ASR service a short opportunity to send its authoritative final. */
    private fun scheduleFinalResultRescue() {
        cancelSpeechRescueTimers()
        val task = Runnable {
            finalResultRescue = null
            if (!listeningSession) return@Runnable
            if (!hadSegmentThisSession) {
                val recovered = commitRecoveredPartial()
                listenStatus.text = if (recovered) "영어 확정 지연 · 마지막 인식으로 번역/기록"
                    else "영어 확정 응답 없음 · 다시 듣기 시도"
            }
            restartStalledRecognizer()
        }
        finalResultRescue = task
        handler.postDelayed(task, FINAL_RESULT_GRACE_MS)
    }

    /** The recognizer might stop reporting anything without calling onEndOfSpeech(). */
    private fun scheduleIdlePartialRescue() {
        if (finalResultRescue != null) return // end-of-speech deadline wins
        idlePartialRescue?.let(handler::removeCallbacks)
        val task = Runnable {
            idlePartialRescue = null
            if (!listeningSession) return@Runnable
            if (commitRecoveredPartial()) {
                listenStatus.text = "인식 응답 지연 · 중간 영어를 자동 기록"
                restartStalledRecognizer()
            }
        }
        idlePartialRescue = task
        handler.postDelayed(task, PARTIAL_IDLE_GRACE_MS)
    }

    private fun cancelSpeechRescueTimers() {
        finalResultRescue?.let(handler::removeCallbacks)
        idlePartialRescue?.let(handler::removeCallbacks)
        finalResultRescue = null
        idlePartialRescue = null
    }

    /** Saves a partial exactly once if an ASR session cannot produce a final callback. */
    private fun commitRecoveredPartial(): Boolean {
        if (!listeningSession) return false
        val text = recovery.takeFallback()
        if (text.isNullOrBlank()) return vm.finalizeEnglishDraft()
        vm.onEnglishFinal(text)
        consecutiveErrors = 0
        return true
    }

    /** A cancelled recognizer cannot keep ownership of the next audio session. */
    private fun restartStalledRecognizer() {
        cancelSpeechRescueTimers()
        cancelBoostWatchdog()
        boostedSource?.close()
        boostedSource = null
        if (!listeningSession) return
        listeningSession = false
        try { recognizer?.cancel() } catch (_: Exception) { }
        destroyRecognizer() // increment epoch: ignore delayed callbacks from the old service
        if (keepListening && settings.continuousListening) scheduleNextListen(230L)
        else {
            stopListening()
            listenStatus.text = "인식 구간 처리 완료 · 듣기 중지"
        }
    }

    private fun endSessionAndPossiblyRestart() {
        if (!listeningSession) return
        cancelSpeechRescueTimers()
        cancelBoostWatchdog()
        boostedSource?.close()
        boostedSource = null
        listeningSession = false
        if (keepListening && settings.continuousListening) {
            recycleRecognizerIfNeeded()
            scheduleNextListen(if (settings.fastRestart) 80L else 300L)
        } else {
            stopListening()
            listenStatus.text = "한 문장 인식 완료 · 마이크 중지"
        }
    }

    private fun cancelBoostWatchdog() {
        boostWatchdog?.let(handler::removeCallbacks)
        boostWatchdog = null
    }

    private fun scheduleBoostWatchdog() {
        cancelBoostWatchdog()
        val watchdog = Runnable {
            boostWatchdog = null
            if (keepListening && listeningSession && boostedSource != null && !heardSpeechThisSession) {
                boostedDisabledThisRun = true
                try { recognizer?.cancel() } catch (_: Exception) { }
                boostedSource?.close()
                boostedSource = null
                listeningSession = false
                audioHint.text = "PCM 음성 입력 응답 없음 · 일반 마이크로 자동 전환"
                if (settings.continuousListening) scheduleNextListen(220L)
                else stopListening()
            }
        }
        boostWatchdog = watchdog
        handler.postDelayed(watchdog, 10_000L)
    }

    private fun scheduleNextListen(delayMs: Long) {
        restart?.let(handler::removeCallbacks)
        if (!keepListening || !settings.continuousListening) return
        val next = Runnable { restart = null; if (keepListening) startSpeechSession() }
        restart = next
        handler.postDelayed(next, delayMs)
    }

    private fun recycleRecognizerIfNeeded() {
        if (!settings.keepRecognizerWarm) {
            // Avoid destroying the recognizer synchronously from its own Binder callback.
            handler.post { if (!listeningSession) destroyRecognizer() }
        }
    }

    private fun stopListening() {
        // Preserve words spoken just before a manual stop, settings change or backgrounding.
        commitRecoveredPartial()
        vm.finalizeEnglishDraft()
        cancelSpeechRescueTimers()
        cancelBoostWatchdog()
        keepListening = false
        boostedSource?.close()
        boostedSource = null
        restart?.let(handler::removeCallbacks)
        restart = null
        microphoneButton.text = "🎙 영어 듣기 시작"
        audioLevel.progress = 0
        listenStatus.text = "듣기 중지 · 다시 누르면 시작합니다."
        if (listeningSession) {
            listeningSession = false
            try { recognizer?.cancel() } catch (_: Exception) { }
        }
        vm.clearPartial()
        if (!settings.keepRecognizerWarm) destroyRecognizer()
    }

    private fun destroyRecognizer() {
        recognizerEpoch++
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
    }

    private fun requestSpeechModel() {
        if (!createRecognizerIfNeeded()) return
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                recognizer?.triggerModelDownload(intentForEnglish())
                listenStatus.text = "영어 오프라인 모델 다운로드를 요청했습니다. 완료 후 다시 시작하세요."
            } catch (e: Exception) {
                listenStatus.text = "모델 요청 실패: ${e.message}"
            }
        } else {
            listenStatus.text = "기기 설정에서 영어 오프라인 음성 인식 언어를 설치해 주세요."
        }
    }

    private fun show(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onStop() {
        // Foreground only; no undisclosed background recording.
        stopListening()
        try { recognizer?.cancel() } catch (_: Exception) { }
        super.onStop()
    }

    override fun onDestroy() {
        destroyRecognizer()
        super.onDestroy()
    }
}
