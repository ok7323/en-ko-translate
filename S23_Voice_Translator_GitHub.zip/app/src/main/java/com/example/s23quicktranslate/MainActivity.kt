package com.example.s23quicktranslate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/** Foreground microphone -> guaranteed on-device platform ASR -> translation. */
class MainActivity : ComponentActivity() {
    private val vm: TranslatorViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private var settings = VoiceSettings()
    private var recognizer: SpeechRecognizer? = null
    private var keepListening = false
    private var listeningSession = false
    private var restart: Runnable? = null
    private var lastError: String? = null
    private var modeUpdating = false
    private var segmentedTemporarilyDisabled = false
    private var hadSegmentThisSession = false
    private var consecutiveErrors = 0
    private val offlineSpeechAvailable: Boolean by lazy {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
    }

    private lateinit var microphoneButton: Button
    private lateinit var speechSetupButton: Button
    private lateinit var fastPrepareButton: Button
    private lateinit var aiDownloadButton: Button
    private lateinit var modeGroup: RadioGroup
    private lateinit var listenStatus: TextView
    private lateinit var engineStatus: TextView
    private lateinit var englishText: TextView
    private lateinit var koreanText: TextView
    private lateinit var metrics: TextView
    private lateinit var downloadProgress: ProgressBar

    private val requestMicrophone = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else show("마이크 권한을 허용해 주세요.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = VoiceSettings.load(this)
        setContentView(R.layout.activity_main)
        microphoneButton = findViewById(R.id.microphoneButton)
        speechSetupButton = findViewById(R.id.speechSetupButton)
        fastPrepareButton = findViewById(R.id.fastPrepareButton)
        aiDownloadButton = findViewById(R.id.aiDownloadButton)
        modeGroup = findViewById(R.id.modeGroup)
        listenStatus = findViewById(R.id.listenStatus)
        engineStatus = findViewById(R.id.engineStatus)
        englishText = findViewById(R.id.englishText)
        koreanText = findViewById(R.id.koreanText)
        metrics = findViewById(R.id.metricsText)
        downloadProgress = findViewById(R.id.downloadProgress)

        microphoneButton.setOnClickListener { toggleMicrophone() }
        speechSetupButton.setOnClickListener { requestSpeechModel() }
        fastPrepareButton.setOnClickListener { vm.prepareFastModel() }
        aiDownloadButton.setOnClickListener { vm.downloadAiModel() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            stopListening()
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener { vm.clearTranscript() }
        findViewById<Button>(R.id.copyButton).setOnClickListener {
            val korean = vm.state.value.koreanHistory
            if (korean.isNotBlank()) {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("Korean translation", korean))
                show("한국어 번역을 복사했습니다.")
            }
        }
        modeGroup.setOnCheckedChangeListener { _, id ->
            if (!modeUpdating) {
                stopListening()
                vm.selectMode(if (id == R.id.modeAi) TranslationMode.GPU_AI else TranslationMode.FAST)
            }
        }
        if (!offlineSpeechAvailable) {
            listenStatus.text = "기기 내 음성 인식 서비스가 없습니다. 음성 입력 서비스를 확인하세요."
            microphoneButton.isEnabled = false
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val newSettings = VoiceSettings.load(this)
        if (newSettings != settings) {
            stopListening()
            settings = newSettings
            segmentedTemporarilyDisabled = false
            if (!settings.keepRecognizerWarm) destroyRecognizer()
        }
        vm.applySettings(settings)
        if (settings.keepRecognizerWarm && offlineSpeechAvailable && hasMicPermission()) {
            createRecognizerIfNeeded() // Does not start recording.
        }
    }

    private fun render(s: VoiceUiState) {
        modeUpdating = true
        modeGroup.check(if (s.mode == TranslationMode.FAST) R.id.modeFast else R.id.modeAi)
        modeUpdating = false
        engineStatus.text = s.status + when {
            s.mode == TranslationMode.FAST -> "\n번역: ML Kit 온디바이스 · GPU/NPU 지정 불가"
            s.aiBackend == ComputeMode.GPU -> "\n고급 번역: Adreno GPU (OpenCL)"
            s.aiBackend == ComputeMode.CPU -> "\n고급 번역: CPU"
            !s.settings.preferGpuForAi -> "\n고급 번역: CPU 선택"
            else -> "\n고급 번역: GPU 우선${if (s.settings.aiCpuFallback) " → CPU 대체" else " (대체 꺼짐)"}"
        }
        englishText.text = listOf(
            s.englishHistory,
            s.englishPartial.takeIf { it.isNotBlank() }?.let { "🎤 $it" }
        ).filterNotNull().filter { it.isNotBlank() }.joinToString("\n").ifBlank {
            "마이크를 누른 다음 영어로 말하세요."
        }
        koreanText.text = listOf(
            s.koreanHistory,
            s.koreanPartial.takeIf { it.isNotBlank() }?.let { "… $it" }
        ).filterNotNull().filter { it.isNotBlank() }.joinToString("\n").ifBlank {
            "영어를 듣는 동안 또는 문장 확정 후 한국어가 표시됩니다."
        }
        metrics.visibility = if (s.settings.showMetrics) View.VISIBLE else View.GONE
        metrics.text = s.speedInfo.ifBlank { "측정 대기 · 영어로 말하면 ASR/번역 지연을 표시합니다." }
        val usingFast = s.mode == TranslationMode.FAST
        fastPrepareButton.visibility = if (usingFast && !s.fastReady) View.VISIBLE else View.GONE
        fastPrepareButton.isEnabled = !s.fastPreparing
        fastPrepareButton.text = if (s.fastPreparing) "한국어 모델 준비 중…" else "빠른 번역 모델 다운로드 / 확인"
        aiDownloadButton.visibility = if (!usingFast && !s.aiModelPresent) View.VISIBLE else View.GONE
        aiDownloadButton.isEnabled = !s.aiDownloading && !s.aiChecking
        aiDownloadButton.text = if (s.aiDownloading) "AI 모델 다운로드 중…" else "고급 AI 모델 다운로드 · 약 347MB"
        downloadProgress.visibility = if (s.aiDownloading) View.VISIBLE else View.GONE
        if (s.aiDownloading) {
            downloadProgress.progress = (s.downloadBytes * 100 / s.totalBytes.coerceAtLeast(1)).toInt().coerceIn(0, 100)
        }
        microphoneButton.isEnabled = offlineSpeechAvailable && (keepListening || s.readyForMic)
        microphoneButton.text = if (keepListening) "■ 듣기 중지" else "🎙 영어 듣기 시작"
        speechSetupButton.isEnabled = offlineSpeechAvailable && !keepListening
        modeGroup.isEnabled = !s.busy
        findViewById<Button>(R.id.copyButton).isEnabled = s.koreanHistory.isNotBlank()
        if (s.error != null && s.error != lastError) show(s.error)
        lastError = s.error
    }

    private fun hasMicPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toggleMicrophone() {
        if (keepListening) stopListening()
        else if (!hasMicPermission()) requestMicrophone.launch(Manifest.permission.RECORD_AUDIO)
        else startListening()
    }

    private fun intentForEnglish() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, settings.partialCaptions || settings.partialTranslation)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        if (Build.VERSION.SDK_INT >= 33 && settings.fastRestart) {
            putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_LATENCY)
        }
        if (settings.shortSilenceEndpoint || (settings.segmentedRecognition && !segmentedTemporarilyDisabled)) {
            // Platform end-pointing hint, not an independent neural VAD. A recognizer may ignore it.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                if (settings.shortSilenceEndpoint) 500 else 850)
        }
        if (Build.VERSION.SDK_INT >= 33 && settings.segmentedRecognition && !segmentedTemporarilyDisabled) {
            putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION,
                RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS)
        }
    }

    private fun createRecognizerIfNeeded(): Boolean {
        if (recognizer != null) return true
        if (!offlineSpeechAvailable) {
            listenStatus.text = "영어 오프라인 음성 인식 서비스가 없습니다."
            return false
        }
        return try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        listenStatus.text = "🎙 듣는 중 · 영어로 말해 주세요."
                    }
                    override fun onBeginningOfSpeech() {
                        listenStatus.text = "영어를 듣고 있습니다…"
                        vm.onSpeechStarted()
                    }
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() {
                        listenStatus.text = "문장 확정 중…"
                        vm.onSpeechEnded()
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    override fun onPartialResults(results: Bundle?) {
                        if (settings.partialCaptions || settings.partialTranslation) {
                            val text = firstResult(results)
                            if (text.isNotBlank()) vm.onEnglishPartial(text)
                        }
                    }
                    override fun onSegmentResults(segmentResults: Bundle) {
                        if (!listeningSession) return
                        val text = firstResult(segmentResults)
                        if (text.isNotBlank()) {
                            hadSegmentThisSession = true
                            vm.onEnglishFinal(text)
                            consecutiveErrors = 0
                            if (!settings.continuousListening) {
                                stopListening()
                                listenStatus.text = "한 구간 인식 완료 · 마이크 중지"
                            } else {
                                listenStatus.text = "구간 인식 완료 · 계속 듣는 중"
                            }
                        }
                    }
                    override fun onEndOfSegmentedSession() {
                        endSessionAndPossiblyRestart()
                    }
                    override fun onResults(results: Bundle?) {
                        if (!listeningSession) return
                        val text = firstResult(results)
                        // Some services send onResults as well as segment callbacks; ViewModel dedupes.
                        if (text.isNotBlank()) {
                            vm.onEnglishFinal(text)
                            consecutiveErrors = 0
                        } else if (!hadSegmentThisSession) vm.clearPartial()
                        endSessionAndPossiblyRestart()
                    }
                    override fun onError(error: Int) {
                        if (!keepListening) return
                        listeningSession = false
                        vm.clearPartial()
                        if (settings.segmentedRecognition && !segmentedTemporarilyDisabled &&
                            (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY)) {
                            segmentedTemporarilyDisabled = true
                            listenStatus.text = "구간 인식 미지원 가능 · 일반 인식으로 전환"
                        }
                        when (error) {
                            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
                            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> {
                                stopListening()
                                listenStatus.text = "영어 오프라인 모델이 없습니다. '영어 음성 모델 받기'를 누르세요."
                                return
                            }
                        }
                        if (!settings.continuousListening) {
                            stopListening()
                            listenStatus.text = "음성 인식 오류($error)"
                            return
                        }
                        consecutiveErrors++
                        if (consecutiveErrors > 5) {
                            stopListening()
                            listenStatus.text = "음성 인식 오류가 반복돼 중단했습니다($error). 다시 시도해 주세요."
                            return
                        }
                        val delay = when (error) {
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> 180L
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> 650L
                            else -> 850L
                        }
                        recycleRecognizerIfNeeded()
                        scheduleNextListen(delay * consecutiveErrors.coerceAtMost(3))
                    }
                })
            }
            true
        } catch (e: Exception) {
            listenStatus.text = "음성 인식 초기화 오류: ${e.message}"
            false
        }
    }

    private fun firstResult(bundle: Bundle?): String = bundle
        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        ?.firstOrNull().orEmpty().trim()

    private fun startListening() {
        if (!vm.state.value.readyForMic) {
            show("먼저 현재 번역 모델을 준비하세요.")
            return
        }
        if (!hasMicPermission()) {
            requestMicrophone.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!createRecognizerIfNeeded()) return
        consecutiveErrors = 0
        keepListening = true
        segmentedTemporarilyDisabled = false
        microphoneButton.text = "■ 듣기 중지"
        startSpeechSession()
    }

    private fun startSpeechSession() {
        if (!keepListening || listeningSession) return
        if (!createRecognizerIfNeeded()) {
            stopListening()
            return
        }
        try {
            listeningSession = true
            hadSegmentThisSession = false
            recognizer?.startListening(intentForEnglish())
        } catch (e: Exception) {
            listeningSession = false
            stopListening()
            listenStatus.text = "마이크 시작 실패: ${e.message}"
        }
    }

    private fun endSessionAndPossiblyRestart() {
        if (!listeningSession) return
        listeningSession = false
        if (keepListening && settings.continuousListening) {
            recycleRecognizerIfNeeded()
            scheduleNextListen(if (settings.fastRestart) 80L else 300L)
        } else {
            stopListening()
            listenStatus.text = "한 문장 인식 완료 · 마이크 중지"
        }
    }

    private fun scheduleNextListen(delayMs: Long) {
        restart?.let(handler::removeCallbacks)
        if (!keepListening || !settings.continuousListening) return
        val next = Runnable { restart = null; if (keepListening) startSpeechSession() }
        restart = next
        handler.postDelayed(next, delayMs)
    }

    private fun recycleRecognizerIfNeeded() {
        if (!settings.keepRecognizerWarm) {
            // Avoid destroying the recognizer synchronously from its own Binder callback.
            handler.post { if (!listeningSession) destroyRecognizer() }
        }
    }

    private fun stopListening() {
        keepListening = false
        restart?.let(handler::removeCallbacks)
        restart = null
        microphoneButton.text = "🎙 영어 듣기 시작"
        listenStatus.text = "듣기 중지 · 다시 누르면 시작합니다."
        if (listeningSession) {
            listeningSession = false
            try { recognizer?.cancel() } catch (_: Exception) { }
        }
        vm.clearPartial()
        if (!settings.keepRecognizerWarm) destroyRecognizer()
    }

    private fun destroyRecognizer() {
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
    }

    private fun requestSpeechModel() {
        if (!createRecognizerIfNeeded()) return
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                recognizer?.triggerModelDownload(intentForEnglish())
                listenStatus.text = "영어 오프라인 모델 다운로드를 요청했습니다. 완료 후 다시 시작하세요."
            } catch (e: Exception) {
                listenStatus.text = "모델 요청 실패: ${e.message}"
            }
        } else {
            listenStatus.text = "기기 설정에서 영어 오프라인 음성 인식 언어를 설치해 주세요."
        }
    }

    private fun show(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onStop() {
        // Foreground only; no undisclosed background recording.
        stopListening()
        try { recognizer?.cancel() } catch (_: Exception) { }
        super.onStop()
    }

    override fun onDestroy() {
        destroyRecognizer()
        super.onDestroy()
    }
}
