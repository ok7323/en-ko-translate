package com.example.s23quicktranslate

import java.util.Locale

/** Benchmarks are identical to the independent tablet HTML test deck, by ID and text. */
data class BenchmarkCase(val id: String, val group: String, val referenceEnglish: String, val referenceKorean: String) {
    val isNoise: Boolean get() = referenceEnglish.isBlank()
}

object BenchmarkCases {
    val all = listOf(
        BenchmarkCase("G01", "일반·짧은", "Hello, hello.", "안녕하세요, 안녕하세요."),
        BenchmarkCase("G02", "일반·짧은", "Can you hear me clearly?", "제 목소리 잘 들리세요?"),
        BenchmarkCase("G03", "일반·짧은", "Please wait a moment.", "잠시만 기다려 주세요."),
        BenchmarkCase("G04", "일반·중간", "I think we should start the meeting in five minutes.", "5분 후에 회의를 시작하는 게 좋겠습니다."),
        BenchmarkCase("G05", "일반·긴 문장", "If the connection becomes unstable, we will take a short break and try again.", "연결이 불안정해지면 잠시 쉬었다가 다시 시도하겠습니다."),
        BenchmarkCase("I01", "인터뷰", "Could you tell me about your previous work experience?", "이전 업무 경험에 대해 말씀해 주시겠습니까?"),
        BenchmarkCase("I02", "인터뷰", "What was the biggest challenge you faced last year?", "작년에 직면했던 가장 큰 어려움은 무엇이었나요?"),
        BenchmarkCase("I03", "인터뷰", "I collaborated with a small team to improve the response time.", "저는 소규모 팀과 협력하여 응답 시간을 개선했습니다."),
        BenchmarkCase("I04", "인터뷰", "How do you handle disagreements with your coworkers?", "동료와 의견이 다를 때 어떻게 해결하나요?"),
        BenchmarkCase("I05", "인터뷰", "Thank you for taking the time to speak with us today.", "오늘 시간을 내어 이야기해 주셔서 감사합니다."),
        BenchmarkCase("C01", "교회 설교", "Good morning, everyone. Welcome to today’s worship service.", "여러분, 좋은 아침입니다. 오늘 예배에 오신 것을 환영합니다."),
        BenchmarkCase("C02", "교회 설교", "Today we will reflect on faith, grace, and forgiveness.", "오늘은 믿음, 은혜, 용서에 대해 묵상하겠습니다."),
        BenchmarkCase("C03", "교회 설교", "The Holy Spirit gives us strength when we feel weak.", "성령께서는 우리가 연약할 때 힘을 주십니다."),
        BenchmarkCase("C04", "교회 설교", "Let us open our Bibles and read the passage together.", "성경을 펴고 본문을 함께 읽겠습니다."),
        BenchmarkCase("C05", "교회 설교", "We are called to love our neighbors even when it is difficult.", "어려울 때에도 이웃을 사랑하도록 부르심을 받았습니다."),
        BenchmarkCase("S01", "소모임", "Would anyone like to share a prayer request?", "기도 제목을 나누실 분 계신가요?"),
        BenchmarkCase("S02", "소모임", "I had a difficult week, but I am thankful for your support.", "힘든 한 주였지만 여러분의 도움에 감사드립니다."),
        BenchmarkCase("S03", "소모임", "Can we take turns so everyone has a chance to speak?", "모두 발언할 수 있도록 돌아가면서 이야기할까요?"),
        BenchmarkCase("S04", "소모임", "I agree with your point, but I see it a little differently.", "말씀하신 점에 동의하지만 제 생각은 조금 다릅니다."),
        BenchmarkCase("S05", "소모임", "Let us meet again next Thursday after dinner.", "다음 주 목요일 저녁 식사 후에 다시 모입시다."),
        BenchmarkCase("N01", "잡음만", "", ""),
        BenchmarkCase("N02", "무음", "", "")
    )
}

data class WordScore(val errors: Int, val referenceWords: Int) {
    val werPercent: Double get() = if (referenceWords > 0) errors.toDouble() * 100.0 / referenceWords else 0.0
}

/** Classic Levenshtein WER; no Korean string matching because valid translations are not unique. */
object BenchmarkScoring {
    fun words(input: String): List<String> {
        val norm = input.lowercase(Locale.US)
            .replace('’', '\'').replace('‘', '\'')
            .replace(Regex("[^a-z0-9' ]"), " ").trim()
            .replace(Regex("\\s+"), " ")
        return if (norm.isEmpty()) emptyList() else norm.split(' ')
    }

    fun score(reference: String, recognized: String): WordScore {
        val a = words(reference)
        val b = words(recognized)
        var prev = IntArray(b.size + 1) { it }
        for (i in a.indices) {
            val next = IntArray(b.size + 1)
            next[0] = i + 1
            for (j in b.indices) {
                next[j + 1] = minOf(next[j] + 1, prev[j + 1] + 1,
                    prev[j] + if (a[i] == b[j]) 0 else 1)
            }
            prev = next
        }
        return WordScore(prev[b.size], a.size)
    }
}

data class BenchmarkTrial(
    val timestamp: Long,
    val caseId: String,
    val condition: String,
    val repetition: Int,
    val version: String,
    val accuracy: String,
    val context: String,
    val english: String,
    val korean: String,
    val englishChecked: Boolean,
    val koreanChecked: Boolean,
    val quality: Int,  // 0: not graded; 1-5: manually assessed semantic adequacy
    val firstEnglishMs: Long?, // from pressing 'start test', NOT from end of audio playback
    val firstKoreanMs: Long?,
    val capturedCount: Int,
    val transcriptIds: List<Long> = emptyList(),
    val note: String = ""
) {
    val testCase: BenchmarkCase? get() = BenchmarkCases.all.firstOrNull { it.id == caseId }
    val wordScore: WordScore? get() = testCase?.takeUnless { it.isNoise }
        ?.let { BenchmarkScoring.score(it.referenceEnglish, english) }
    val falsePositive: Boolean get() = testCase?.isNoise == true && english.isNotBlank()
    val hasKorean: Boolean get() = korean.isNotBlank() && !korean.contains("[번역 실패]")
}

object BenchmarkSummary {
    fun format(trials: List<BenchmarkTrial>): String {
        val spoken = trials.filter { it.testCase?.isNoise == false }
        val noise = trials.filter { it.testCase?.isNoise == true }
        val scores = spoken.mapNotNull { it.wordScore }
        val words = scores.sumOf { it.referenceWords }
        val errors = scores.sumOf { it.errors }
        val recorded = spoken.count { it.english.isNotBlank() }
        val translated = spoken.count { it.english.isNotBlank() && it.hasKorean }
        val graded = spoken.filter { it.quality in 1..5 }
        val firstKo = spoken.mapNotNull { it.firstKoreanMs }
        fun pct(n: Int, d: Int) = if (d == 0) "—" else "%.1f%%".format(Locale.US, n * 100.0 / d)
        return "시험 ${trials.size}회  ·  WER ${pct(errors, words)}\n" +
            "영어 기록률 ${pct(recorded, spoken.size)}  ·  번역 완료율 ${pct(translated, recorded)}\n" +
            "잡음/무음 오인식 ${noise.count { it.falsePositive }} / ${noise.size}회\n" +
            "한국어 수동평가 " + (if (graded.isEmpty()) "—" else "%.2f/5".format(Locale.US, graded.map { it.quality }.average())) +
            "  ·  한국어 첫 표시 " + (if (firstKo.isEmpty()) "—" else "%.0fms".format(Locale.US, firstKo.average()))
    }
}
