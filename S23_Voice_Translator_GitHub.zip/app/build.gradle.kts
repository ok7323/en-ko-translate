plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.s23quicktranslate"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.s23quicktranslate"
        minSdk = 31
        targetSdk = 35
        versionCode = 11
        versionName = "10.0.0-benchmark"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

// Kotlin 2.3+: android.kotlinOptions is an error.
// Keep Kotlin bytecode level in sync with android.compileOptions above.
kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-ktx:1.11.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.9.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    // Default low-latency on-device English -> Korean NMT.
    implementation("com.google.mlkit:translate:17.0.3")

    // Optional high-quality GPU mode: Adreno/OpenCL, with CPU fallback.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")

    testImplementation("junit:junit:4.13.2")
}
