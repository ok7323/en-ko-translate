# v10.0 — On-device benchmark test tab

- Added `통역 · 기록` and `성능 테스트` tabs inside the same Activity. The microphone stays foreground and active while switching tabs.
- Included the same 22 cases as the earlier tablet HTML deck. Tablet is now playback-only.
- Each trial arms from the current last transcript ID; only newly added transcript IDs are linked to that trial. Manually stop to save an empty/missed attempt, too.
- Auto-captures recognized English and Korean; later translations update the linked stored trial.
- Added automatic WER (word-level edit distance), transcription coverage, translation completion, silent/noise false-positive counts, and manual 1–5 Korean adequacy ratings.
- Added condition, repetition, app version, speaker/context settings, verification checkboxes, and free-form notes.
- Saved benchmark trial data in app-private JSON using Android AtomicFile. CSV export uses Android's Save As document chooser (UTF-8 with BOM).
- Latencies are arm-button-relative, not playback-end-relative. No claim of direct synchronized latency measurements.
- Regression tests for scoring, deck size, omissions, punctuation and false-positive noise classification.
- Build not executed here; Android SDK/Gradle runtime not present.
