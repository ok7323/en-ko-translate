import com.example.s23quicktranslate.*
fun main() {
    check(BenchmarkCases.all.size == 22)
    check(BenchmarkCases.all.count { !it.isNoise } == 20)
    check(BenchmarkCases.all.count { it.isNoise } == 2)
    check(BenchmarkScoring.score("Hello, hello.", "hello hello!").errors == 0)
    check(BenchmarkScoring.score("Please wait a moment.", "").werPercent == 100.0)
    check(BenchmarkScoring.score("we will meet", "we may meet soon").errors == 2)
    check(BenchmarkScoring.score("Today's service", "today’s service").errors == 0)
    val e=BenchmarkTrial(1,"N01","noise",1,"v10","중","general","hello","",false,false,0,null,null,1)
    check(e.falsePositive)
    val blank=BenchmarkTrial(1,"G01","quiet",1,"v10","중","general","","",false,false,0,null,null,0)
    check(BenchmarkSummary.format(listOf(blank)).contains("100.0%"))
    println("9 benchmark smoke checks PASS")
}
