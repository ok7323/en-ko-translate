# S23 Voice Translator v4.0

Android English speech → Korean on-device translation project. Download the ZIP as-is and upload `S23_Voice_Translator_GitHub.zip` to the root of an existing GitHub repository with the `build-apk.yml` workflow from prior releases. The ZIP contents must remain at its own archive root; GitHub Actions extracts them into `source/`.

## New in v4.0

Two Settings dropdowns:
- **Accuracy:** High (contextual AI if locally ready, else ML Kit + selected glossary), Medium (ML Kit + conservative, context-gated corrections), Low (low latency ML Kit, no corrections).
- **Situation:** General / Interview / Christian Sermon / Small Group.

An AI model is **optional**, is not silently downloaded, and may be slower or less accurate than ML Kit for some phrases. The labels High/Medium/Low are **processing modes**, not benchmarked accuracy grades. ML Kit has no native domain prompt; only exact source-gated corrections are applied on that path. The optional LiteRT-LM AI translator receives a contextual prompt; High mode also uses up to two preceding finalized English statements. All model data stay on-device after downloading.

The existing 13 feature checkboxes, intermediate speech recognition, ML Kit/AI model setup, GPU/CPU fallback, and GitHub source ZIP workflow are retained. Read `README_한국어.md` for installation details and limitations.

**Build and device status**: Not compiled with an Android SDK or tested on an S23 in this environment. Test with GitHub Actions and real device before deployment.

## v5: Quiet voices + bilingual conversation history

- Optional quiet speech mode requests longer endpointing pauses; **not actual microphone gain** (Android recognizer may ignore hints).
- Experimental amplified PCM injection (off by default): AudioRecord + bounded sample gain + `RecognizerIntent.EXTRA_AUDIO_SOURCE` on API33+; automatically switches back to native microphone upon incompatible recognition errors. This is not guaranteed to work on the S23 recognizer.
- Optional ASR phrase biasing for interview/sermon/small-group contexts, subject to recognizer support.
- RecyclerView displays paired English/Korean utterances, in capture order, with timestamps and incremental translation updates.
- Local JSONL journal restores past recordings, manual text export via Storage Access Framework, copy, clear confirmation, and optional auto-follow.
- Existing GitHub build workflow continues to consume `S23_Voice_Translator_GitHub.zip` at repository root.
