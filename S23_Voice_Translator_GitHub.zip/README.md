# S23 Voice Translator v3.0 — GitHub ZIP-upload build

Android 12+ English speech → offline Korean translation app with 13 persisted feature checkboxes and a 100–600ms partial-translation scheduling slider.

**Upload `S23_Voice_Translator_GitHub.zip` to the ROOT of your GitHub repository without extracting.** Keep the existing `.github/workflows/build-apk.yml` that extracts the source ZIP (the corrected `build-apk_ACTION_FIXED.yml` from the previous release). GitHub cannot run workflows stored only inside a ZIP.

Go to **Actions → Build S23 Voice Translator APK → Run workflow**; after a successful build, fetch `app-debug.apk` from Artifacts.

The default ASR is Android's on-device SpeechRecognizer. Optional segmented results use API 33's `EXTRA_SEGMENTED_SESSION`/`onSegmentResults`. ASR partial results drive optional stable-prefix speculative translation through ML Kit; finalized sentences are translated separately. Results from superseded speculative translation requests are ignored. The advanced model uses optional LiteRT-LM Adreno GPU, CPU if selected/available.

See [README_한국어.md](README_한국어.md) for each checkbox, setup, and limitations.

**Limitations:** Android endpointing hints are *not* an independently embedded neural VAD, and segmented mode support varies by speech service. This build does **not** bundle sherpa-onnx or implement Qualcomm NPU inference. ML Kit doesn't expose direct GPU/NPU backend selection. English recognition requires an on-device model installed by the system. Microphone only runs in the foreground. No actual Android/Galaxy S23 build or hardware benchmark could be performed here.

Repository layout: `app/`, `build.gradle.kts`, `settings.gradle.kts`. Build with Android SDK 36, Gradle 8.13, JDK 17:

```bash
gradle :app:testDebugUnitTest :app:assembleDebug
```
