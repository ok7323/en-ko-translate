## v8.0 — Noise suppression and top-row translation profiles

The home screen now has **Accuracy: High/Medium/Low** and **Context: General/Interview/Church sermon/Small group** selectors in one horizontal row. Both save immediately and affect the translation policy. The Settings screen includes an **ambient-noise filter** (enabled by default) and **Gentle/Normal/Strong** thresholds. A heuristic RMS noise floor gates recognition hypotheses, and timeouts split stalled speech sessions. No guarantee of complete white-noise removal: recognition callbacks are service-dependent and there is no neural VAD or spectral source separation. Existing English-first history is retained for accepted speech.

# S23 Voice Translator v8.0

Android English speech → Korean on-device translation project. Download the ZIP as-is and upload `S23_Voice_Translator_GitHub.zip` to the root of an existing GitHub repository with the `build-apk.yml` workflow from prior releases. The ZIP contents must remain at its own archive root; GitHub Actions extracts them into `source/`.

## New in v4.0

Two translation profile dropdowns (now on the home screen):
- **Accuracy:** High (contextual AI if locally ready, else ML Kit + selected glossary), Medium (ML Kit + conservative, context-gated corrections), Low (low latency ML Kit, no corrections).
- **Situation:** General / Interview / Christian Sermon / Small Group.

An AI model is **optional**, is not silently downloaded, and may be slower or less accurate than ML Kit for some phrases. The labels High/Medium/Low are **processing modes**, not benchmarked accuracy grades. ML Kit has no native domain prompt; only exact source-gated corrections are applied on that path. The optional LiteRT-LM AI translator receives a contextual prompt; High mode also uses up to two preceding finalized English statements. All model data stay on-device after downloading.

The existing 13 feature checkboxes, intermediate speech recognition, ML Kit/AI model setup, GPU/CPU fallback, and GitHub source ZIP workflow are retained. Read `README_한국어.md` for installation details and limitations.

**Build and device status**: Not compiled with an Android SDK or tested on an S23 in this environment. Test with GitHub Actions and real device before deployment.

## v5: Quiet voices + bilingual conversation history

- Optional quiet speech mode requests longer endpointing pauses; **not actual microphone gain** (Android recognizer may ignore hints).
- Experimental amplified PCM injection (off by default): AudioRecord + bounded sample gain + `RecognizerIntent.EXTRA_AUDIO_SOURCE` on API33+; automatically switches back to native microphone upon incompatible recognition errors. This is not guaranteed to work on the S23 recognizer.
- Optional ASR phrase biasing for interview/sermon/small-group contexts, subject to recognizer support.
- RecyclerView displays paired English/Korean utterances, in capture order, with timestamps and incremental translation updates.
- Local JSONL journal restores past recordings, manual text export via Storage Access Framework, copy, clear confirmation, and optional auto-follow.
- Existing GitHub build workflow continues to consume `S23_Voice_Translator_GitHub.zip` at repository root.

## v6.0: English recognition without Korean output or history

Some Android recognition services deliver partial English text without a timely final `onResults()` callback. The app now saves and translates the latest partial when the final remains missing for 1.6 seconds after the end of speech, or when no new partial arrives for 4 seconds. Recovered sessions safely restart without losing the bilingual transcript. A short one-off partial is now eligible for a debounced Korean preview. The actual on-device translator must be downloaded and initialized as before.


## v7: English-first always-on transcript

Every nonempty ASR partial becomes a transcript card immediately, independent of Korean translation availability and the caption/preview toggles. Further partials revise the same card. Final recognition seals the card and queues translation. Error, recognizer restart and manual stop preserve any draft. English capture can start before downloading an ML Kit translation model. When local transcript persistence is enabled (the default), draft revisions are journaled for restoration on relaunch. This records *recognized text*, not raw audio or speech the recognizer failed to hear.
