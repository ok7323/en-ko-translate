# S23 Voice Translator v4.0

Android English speech → Korean on-device translation project. Download the ZIP as-is and upload `S23_Voice_Translator_GitHub.zip` to the root of an existing GitHub repository with the `build-apk.yml` workflow from prior releases. The ZIP contents must remain at its own archive root; GitHub Actions extracts them into `source/`.

## New in v4.0

Two Settings dropdowns:
- **Accuracy:** High (contextual AI if locally ready, else ML Kit + selected glossary), Medium (ML Kit + conservative, context-gated corrections), Low (low latency ML Kit, no corrections).
- **Situation:** General / Interview / Christian Sermon / Small Group.

An AI model is **optional**, is not silently downloaded, and may be slower or less accurate than ML Kit for some phrases. The labels High/Medium/Low are **processing modes**, not benchmarked accuracy grades. ML Kit has no native domain prompt; only exact source-gated corrections are applied on that path. The optional LiteRT-LM AI translator receives a contextual prompt; High mode also uses up to two preceding finalized English statements. All model data stay on-device after downloading.

The existing 13 feature checkboxes, intermediate speech recognition, ML Kit/AI model setup, GPU/CPU fallback, and GitHub source ZIP workflow are retained. Read `README_한국어.md` for installation details and limitations.

**Build and device status**: Not compiled with an Android SDK or tested on an S23 in this environment. Test with GitHub Actions and real device before deployment.
