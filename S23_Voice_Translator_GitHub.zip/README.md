# Galaxy S23 Voice Interpreter · English audio → Korean

**Version 2.0 (voice)**. A real Android app project for Samsung Galaxy S23, packaged so you can upload the single ZIP archive to the existing GitHub Actions ZIP-building workflow.

## What it does

1. Tap **빠른 번역 모델 다운로드 / 확인** once with Internet access. ML Kit downloads or checks the English → Korean on-device translation model.
2. If needed tap **영어 오프라인 음성 모델 받기** to request the English language model from your on-device Android speech recognizer. The speech recognizer service and supported language pack must already be supported by your device.
3. Grant microphone permission when prompted and tap **🎙 영어 듣기 시작**.
4. Speak English. English partial recognition appears quickly; a debounced Korean preview may show while you are talking. The final English segment is queued for translation. Automatic recognition restart enables consecutive utterances while the app is in the foreground.
5. Tap **■ 듣기 중지** to stop. Korean translation text can be copied.

### Speed / acceleration modes

- **⚡ Fast (recommended)** — Android `SpeechRecognizer.createOnDeviceSpeechRecognizer` for *on-device-only* speech-to-text and `com.google.mlkit:translate:17.0.3` for on-device English→Korean neural translation. Lower startup cost than a generative LLM. ML Kit does **not expose a GPU/NPU selection API**, so the app cannot claim specific accelerators for this fast mode.
- **Optional AI GPU mode** — downloads a separate ~347 MB `Qwen3-0.6B-int4` `.litertlm` model; uses LiteRT-LM `Backend.GPU()` (Adreno OpenCL) with CPU fallback. This mode is usually slower than the small NMT translator. It is optional; the first model installation/download needs Internet.
- Qualcomm Hexagon NPU acceleration is **not implemented**. The new Google ML Kit GenAI Speech Translation API does not currently list Galaxy S23 / Snapdragon 8 Gen 2 among supported chipsets, so this project deliberately does not depend on it.

**Privacy:** Audio is submitted only to the selected *on-device* Android SpeechRecognizer service by using `createOnDeviceSpeechRecognizer`; we do not fall back to a network-backed recognizer. Recognized text goes to locally downloaded ML Kit or LiteRT-LM models, never an app-owned server. Some devices may not have on-device English recognition installed. First-time model downloads naturally use network access; `INTERNET` is requested for this purpose.

**Constraints:** Android's recognizer may stop at pauses, and support for automatic restart and interim results varies with recognition service. We restart after the service's final callback with a small delay, but that brief gap can lose words. Recording works only while the Activity remains foregrounded. Translation latency and accelerator availability have **not** been benchmarked on physical S23 hardware.

## Build on GitHub, without extracting ZIP yourself

Use exactly the repository setup that you already have:

- `.github/workflows/build-apk.yml` = previously corrected YAML (`android-actions/setup-android@v4`).
- `S23_QuickTranslate_App.zip` = this new ZIP **with files at ZIP root**.

Upload/replace `S23_QuickTranslate_App.zip` in the repository root and commit. GitHub Actions should run `gradle :app:assembleDebug` and provide `app-debug.apk` in the artifact `S23QuickTranslate-debug-apk` after a successful build.

The previous workflow **does not need modification**. An APK built by GitHub Actions has not yet been verified for this version. Open logs if Gradle or Android SDK errors occur.

## Build locally

Use Android Studio with Java 17, compileSdk 36, Android Gradle Plugin 8.13.2, Kotlin 2.3.0, Gradle 8.13. The GitHub workflow installs Gradle itself, so the ZIP intentionally does not require bundled wrapper binaries.

## Notes

- Microphone permission: `android.permission.RECORD_AUDIO`.
- Manifest `<queries>` includes `android.speech.RecognitionService` so Android's on-device service can be found.
- Min API 31 (Android 12), covering Galaxy S23 and later updates.
- No cloud translation API keys, no audio recording files, no background microphone service.
- AI mode model SHA256 is checked before use; if the model packaging or LiteRT runtime changes, adjust the model + runtime version together and test on device.

Official docs:
- Android `SpeechRecognizer`: https://developer.android.com/reference/android/speech/SpeechRecognizer
- ML Kit translation: https://developers.google.com/ml-kit/language/translation/android
- ML Kit GenAI speech translation supported devices: https://developers.google.com/ml-kit/genai/speech-translation/android
