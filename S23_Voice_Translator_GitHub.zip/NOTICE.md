# Third-party notices

This project relies on the Google AI Edge LiteRT-LM Android runtime and the
Qwen3-0.6B INT4 no-thinking LiteRT-LM conversion.

- Qwen3-0.6B weights: Qwen team, Apache License 2.0.
- INT4 LiteRT-LM conversion: litert-community/Qwen3-0.6B-int4, Apache License 2.0.
- The model weights are not included in this source archive. The application
  downloads them from their original Hugging Face repository when requested.
- Gradle 8.13 distribution is downloaded at build time, SHA-256 checked against
  the release checksum. The tiny WrapperBootstrap.java launcher is original
  source included for transparency and is not Gradle's official wrapper.

- The GitHub Actions workflow intentionally replaces the custom bootstrap JAR
  with an official wrapper generated using Gradle 8.13 before building.
